﻿namespace CarRental
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            textBoxUser = new Guna.UI2.WinForms.Guna2TextBox();
            textBoxPass = new Guna.UI2.WinForms.Guna2TextBox();
            btnLogin = new Guna.UI2.WinForms.Guna2Button();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            btnSup = new Guna.UI2.WinForms.Guna2Button();
            label1 = new Label();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            guna2MessageDialog1 = new Guna.UI2.WinForms.Guna2MessageDialog();
            guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(components);
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2PictureBox1
            // 
            guna2PictureBox1.CustomizableEdges = customizableEdges1;
            guna2PictureBox1.Image = (Image)resources.GetObject("guna2PictureBox1.Image");
            guna2PictureBox1.ImageRotate = 0F;
            guna2PictureBox1.Location = new Point(87, 46);
            guna2PictureBox1.Name = "guna2PictureBox1";
            guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2PictureBox1.Size = new Size(159, 92);
            guna2PictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox1.TabIndex = 0;
            guna2PictureBox1.TabStop = false;
            // 
            // textBoxUser
            // 
            textBoxUser.AutoRoundedCorners = true;
            textBoxUser.BackColor = Color.Transparent;
            textBoxUser.BorderRadius = 17;
            customizableEdges3.BottomLeft = false;
            textBoxUser.CustomizableEdges = customizableEdges3;
            textBoxUser.DefaultText = "";
            textBoxUser.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            textBoxUser.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            textBoxUser.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            textBoxUser.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            textBoxUser.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            textBoxUser.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxUser.ForeColor = Color.Black;
            textBoxUser.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            textBoxUser.Location = new Point(63, 217);
            textBoxUser.Name = "textBoxUser";
            textBoxUser.PasswordChar = '\0';
            textBoxUser.PlaceholderForeColor = Color.DimGray;
            textBoxUser.PlaceholderText = "Username";
            textBoxUser.SelectedText = "";
            textBoxUser.ShadowDecoration.BorderRadius = 15;
            textBoxUser.ShadowDecoration.Color = Color.Maroon;
            textBoxUser.ShadowDecoration.CustomizableEdges = customizableEdges4;
            textBoxUser.Size = new Size(198, 36);
            textBoxUser.TabIndex = 1;
            textBoxUser.TextOffset = new Point(6, 0);
            // 
            // textBoxPass
            // 
            textBoxPass.AutoRoundedCorners = true;
            textBoxPass.BorderRadius = 17;
            customizableEdges5.TopRight = false;
            textBoxPass.CustomizableEdges = customizableEdges5;
            textBoxPass.DefaultText = "";
            textBoxPass.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            textBoxPass.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            textBoxPass.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            textBoxPass.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            textBoxPass.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            textBoxPass.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxPass.ForeColor = Color.Black;
            textBoxPass.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            textBoxPass.Location = new Point(63, 291);
            textBoxPass.Name = "textBoxPass";
            textBoxPass.PasswordChar = '●';
            textBoxPass.PlaceholderForeColor = Color.DimGray;
            textBoxPass.PlaceholderText = "Password";
            textBoxPass.SelectedText = "";
            textBoxPass.ShadowDecoration.CustomizableEdges = customizableEdges6;
            textBoxPass.Size = new Size(199, 36);
            textBoxPass.TabIndex = 2;
            textBoxPass.TextOffset = new Point(6, 0);
            textBoxPass.UseSystemPasswordChar = true;
            // 
            // btnLogin
            // 
            btnLogin.AutoRoundedCorners = true;
            btnLogin.BackColor = Color.FromArgb(10, 123, 165);
            btnLogin.BorderRadius = 17;
            btnLogin.CustomizableEdges = customizableEdges7;
            btnLogin.DisabledState.BorderColor = Color.DarkGray;
            btnLogin.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLogin.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLogin.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLogin.FillColor = Color.FromArgb(213, 10, 70);
            btnLogin.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(27, 373);
            btnLogin.Name = "btnLogin";
            btnLogin.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnLogin.Size = new Size(119, 37);
            btnLogin.TabIndex = 3;
            btnLogin.Text = "Login";
            btnLogin.Click += btnLogin_Click;
            // 
            // btnExit
            // 
            btnExit.AutoRoundedCorners = true;
            btnExit.BorderRadius = 17;
            btnExit.CustomizableEdges = customizableEdges9;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.FromArgb(213, 10, 70);
            btnExit.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnExit.ForeColor = Color.White;
            btnExit.Location = new Point(174, 373);
            btnExit.Name = "btnExit";
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnExit.Size = new Size(119, 37);
            btnExit.TabIndex = 4;
            btnExit.Text = "Exit";
            btnExit.Click += guna2Button2_Click;
            // 
            // btnSup
            // 
            btnSup.AutoRoundedCorners = true;
            btnSup.BackColor = Color.FromArgb(10, 123, 165);
            btnSup.BorderRadius = 35;
            btnSup.CustomizableEdges = customizableEdges11;
            btnSup.DisabledState.BorderColor = Color.DarkGray;
            btnSup.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSup.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSup.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSup.FillColor = Color.FromArgb(10, 123, 165);
            btnSup.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSup.ForeColor = Color.White;
            btnSup.Image = Properties.Resources.user__1_;
            btnSup.ImageSize = new Size(60, 60);
            btnSup.Location = new Point(233, 12);
            btnSup.Name = "btnSup";
            btnSup.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnSup.Size = new Size(86, 73);
            btnSup.TabIndex = 5;
            btnSup.Click += btnSup_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Historic", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(42, 161);
            label1.Name = "label1";
            label1.Size = new Size(142, 21);
            label1.TabIndex = 6;
            label1.Text = "Please Login Enter!";
            label1.Click += label1_Click;
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.AnimateWindow = true;
            guna2BorderlessForm1.AnimationInterval = 250;
            guna2BorderlessForm1.BorderRadius = 3;
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockForm = false;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.ShadowColor = Color.DeepSkyBlue;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2MessageDialog1
            // 
            guna2MessageDialog1.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
            guna2MessageDialog1.Caption = "";
            guna2MessageDialog1.Icon = Guna.UI2.WinForms.MessageDialogIcon.Error;
            guna2MessageDialog1.Parent = this;
            guna2MessageDialog1.Style = Guna.UI2.WinForms.MessageDialogStyle.Dark;
            guna2MessageDialog1.Text = null;
            // 
            // guna2DragControl1
            // 
            guna2DragControl1.DockIndicatorTransparencyValue = 0.6D;
            guna2DragControl1.TargetControl = this;
            guna2DragControl1.UseTransparentDrag = true;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(10, 123, 165);
            ClientSize = new Size(331, 450);
            Controls.Add(label1);
            Controls.Add(btnSup);
            Controls.Add(btnExit);
            Controls.Add(btnLogin);
            Controls.Add(textBoxPass);
            Controls.Add(textBoxUser);
            Controls.Add(guna2PictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            KeyDown += LoginForm_KeyDown;
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Guna.UI2.WinForms.Guna2Button btnLogin;
        private Guna.UI2.WinForms.Guna2TextBox textBoxPass;
        private Guna.UI2.WinForms.Guna2TextBox textBoxUser;
        private Guna.UI2.WinForms.Guna2Button btnSup;
        private Label label1;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2MessageDialog guna2MessageDialog1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
    }
}