﻿namespace CarRental
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            btnCustomer = new Guna.UI2.WinForms.Guna2Button();
            btnHome = new Guna.UI2.WinForms.Guna2Button();
            guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            lblUser = new Label();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(components);
            guna2CustomGradientPanel1.SuspendLayout();
            guna2Panel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.Controls.Add(guna2Button6);
            guna2CustomGradientPanel1.Controls.Add(guna2Button7);
            guna2CustomGradientPanel1.Controls.Add(guna2Button2);
            guna2CustomGradientPanel1.Controls.Add(guna2Button1);
            guna2CustomGradientPanel1.Controls.Add(btnCustomer);
            guna2CustomGradientPanel1.Controls.Add(btnHome);
            guna2CustomGradientPanel1.CustomizableEdges = customizableEdges13;
            guna2CustomGradientPanel1.Dock = DockStyle.Left;
            guna2CustomGradientPanel1.FillColor = Color.FromArgb(35, 55, 73);
            guna2CustomGradientPanel1.FillColor2 = Color.FromArgb(10, 123, 165);
            guna2CustomGradientPanel1.FillColor3 = Color.FromArgb(10, 123, 165);
            guna2CustomGradientPanel1.FillColor4 = Color.FromArgb(35, 55, 73);
            guna2CustomGradientPanel1.Location = new Point(0, 0);
            guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            guna2CustomGradientPanel1.Quality = 15;
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2CustomGradientPanel1.Size = new Size(137, 813);
            guna2CustomGradientPanel1.TabIndex = 0;
            // 
            // guna2Button6
            // 
            guna2Button6.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            guna2Button6.Animated = true;
            guna2Button6.AutoRoundedCorners = true;
            guna2Button6.BackColor = Color.Transparent;
            guna2Button6.BorderRadius = 35;
            guna2Button6.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button6.CustomizableEdges = customizableEdges1;
            guna2Button6.DisabledState.BorderColor = Color.DarkGray;
            guna2Button6.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button6.FillColor = Color.Transparent;
            guna2Button6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button6.ForeColor = Color.White;
            guna2Button6.Image = (Image)resources.GetObject("guna2Button6.Image");
            guna2Button6.ImageOffset = new Point(1, 0);
            guna2Button6.ImageSize = new Size(50, 50);
            guna2Button6.Location = new Point(30, 691);
            guna2Button6.Name = "guna2Button6";
            guna2Button6.ShadowDecoration.BorderRadius = 0;
            guna2Button6.ShadowDecoration.Color = Color.Transparent;
            guna2Button6.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Button6.Size = new Size(80, 73);
            guna2Button6.TabIndex = 2;
            // 
            // guna2Button7
            // 
            guna2Button7.Anchor = AnchorStyles.Left;
            guna2Button7.Animated = true;
            guna2Button7.AutoRoundedCorners = true;
            guna2Button7.BackColor = Color.Transparent;
            guna2Button7.BorderRadius = 35;
            guna2Button7.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button7.CheckedState.BorderColor = Color.FromArgb(0, 0, 192);
            guna2Button7.CustomizableEdges = customizableEdges3;
            guna2Button7.DisabledState.BorderColor = Color.DarkGray;
            guna2Button7.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button7.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button7.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button7.FillColor = Color.Transparent;
            guna2Button7.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button7.ForeColor = Color.White;
            guna2Button7.Image = (Image)resources.GetObject("guna2Button7.Image");
            guna2Button7.ImageOffset = new Point(1, 0);
            guna2Button7.ImageSize = new Size(50, 50);
            guna2Button7.Location = new Point(30, 512);
            guna2Button7.Name = "guna2Button7";
            guna2Button7.ShadowDecoration.BorderRadius = 0;
            guna2Button7.ShadowDecoration.Color = Color.Transparent;
            guna2Button7.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Button7.Size = new Size(80, 73);
            guna2Button7.TabIndex = 2;
            guna2Button7.Click += guna2Button7_Click;
            // 
            // guna2Button2
            // 
            guna2Button2.Anchor = AnchorStyles.Left;
            guna2Button2.Animated = true;
            guna2Button2.AutoRoundedCorners = true;
            guna2Button2.BackColor = Color.Transparent;
            guna2Button2.BorderRadius = 35;
            guna2Button2.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button2.CustomizableEdges = customizableEdges5;
            guna2Button2.DisabledState.BorderColor = Color.DarkGray;
            guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button2.FillColor = Color.Transparent;
            guna2Button2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button2.ForeColor = Color.White;
            guna2Button2.Image = (Image)resources.GetObject("guna2Button2.Image");
            guna2Button2.ImageOffset = new Point(1, 0);
            guna2Button2.ImageSize = new Size(50, 50);
            guna2Button2.Location = new Point(30, 422);
            guna2Button2.Name = "guna2Button2";
            guna2Button2.ShadowDecoration.BorderRadius = 0;
            guna2Button2.ShadowDecoration.Color = Color.Transparent;
            guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Button2.Size = new Size(80, 73);
            guna2Button2.TabIndex = 2;
            guna2Button2.Click += guna2Button2_Click;
            // 
            // guna2Button1
            // 
            guna2Button1.Anchor = AnchorStyles.Left;
            guna2Button1.Animated = true;
            guna2Button1.AutoRoundedCorners = true;
            guna2Button1.BackColor = Color.Transparent;
            guna2Button1.BorderRadius = 35;
            guna2Button1.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button1.CustomizableEdges = customizableEdges7;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.Transparent;
            guna2Button1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Image = (Image)resources.GetObject("guna2Button1.Image");
            guna2Button1.ImageOffset = new Point(1, 0);
            guna2Button1.ImageSize = new Size(50, 50);
            guna2Button1.Location = new Point(30, 332);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.BorderRadius = 0;
            guna2Button1.ShadowDecoration.Color = Color.Transparent;
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2Button1.Size = new Size(80, 73);
            guna2Button1.TabIndex = 2;
            guna2Button1.Click += guna2Button1_Click;
            // 
            // btnCustomer
            // 
            btnCustomer.Anchor = AnchorStyles.Left;
            btnCustomer.Animated = true;
            btnCustomer.AutoRoundedCorners = true;
            btnCustomer.BackColor = Color.Transparent;
            btnCustomer.BorderRadius = 35;
            btnCustomer.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnCustomer.CustomizableEdges = customizableEdges9;
            btnCustomer.DisabledState.BorderColor = Color.DarkGray;
            btnCustomer.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCustomer.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCustomer.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCustomer.FillColor = Color.Transparent;
            btnCustomer.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnCustomer.ForeColor = Color.White;
            btnCustomer.Image = (Image)resources.GetObject("btnCustomer.Image");
            btnCustomer.ImageOffset = new Point(1, 0);
            btnCustomer.ImageSize = new Size(50, 50);
            btnCustomer.Location = new Point(30, 243);
            btnCustomer.Name = "btnCustomer";
            btnCustomer.ShadowDecoration.BorderRadius = 0;
            btnCustomer.ShadowDecoration.Color = Color.Transparent;
            btnCustomer.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnCustomer.Size = new Size(80, 73);
            btnCustomer.TabIndex = 2;
            btnCustomer.Click += btnCustomer_Click;
            // 
            // btnHome
            // 
            btnHome.Animated = true;
            btnHome.AutoRoundedCorners = true;
            btnHome.BackColor = Color.Transparent;
            btnHome.BorderRadius = 35;
            btnHome.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnHome.CheckedState.BorderColor = Color.FromArgb(0, 0, 192);
            btnHome.CustomizableEdges = customizableEdges11;
            btnHome.DisabledState.BorderColor = Color.DarkGray;
            btnHome.DisabledState.CustomBorderColor = Color.DarkGray;
            btnHome.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnHome.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnHome.FillColor = Color.Transparent;
            btnHome.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnHome.ForeColor = Color.White;
            btnHome.Image = Properties.Resources.home;
            btnHome.ImageOffset = new Point(1, 0);
            btnHome.ImageSize = new Size(50, 50);
            btnHome.Location = new Point(30, 41);
            btnHome.Name = "btnHome";
            btnHome.ShadowDecoration.BorderRadius = 0;
            btnHome.ShadowDecoration.Color = Color.Transparent;
            btnHome.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnHome.Size = new Size(80, 73);
            btnHome.TabIndex = 1;
            btnHome.Click += btnHome_Click;
            // 
            // guna2Button3
            // 
            guna2Button3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2Button3.AutoRoundedCorners = true;
            guna2Button3.BackColor = Color.Transparent;
            guna2Button3.BorderRadius = 10;
            guna2Button3.CustomizableEdges = customizableEdges15;
            guna2Button3.DisabledState.BorderColor = Color.DarkGray;
            guna2Button3.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button3.FillColor = Color.Red;
            guna2Button3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button3.ForeColor = Color.White;
            guna2Button3.Location = new Point(1272, 12);
            guna2Button3.Name = "guna2Button3";
            guna2Button3.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2Button3.Size = new Size(23, 23);
            guna2Button3.TabIndex = 1;
            guna2Button3.Click += guna2Button3_Click;
            // 
            // guna2Button4
            // 
            guna2Button4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2Button4.AutoRoundedCorners = true;
            guna2Button4.BackColor = Color.Transparent;
            guna2Button4.BorderRadius = 10;
            guna2Button4.CustomizableEdges = customizableEdges17;
            guna2Button4.DisabledState.BorderColor = Color.DarkGray;
            guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button4.FillColor = Color.DarkGoldenrod;
            guna2Button4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button4.ForeColor = Color.White;
            guna2Button4.Location = new Point(1243, 12);
            guna2Button4.Name = "guna2Button4";
            guna2Button4.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2Button4.Size = new Size(23, 23);
            guna2Button4.TabIndex = 2;
            guna2Button4.Click += guna2Button4_Click;
            // 
            // guna2Button5
            // 
            guna2Button5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2Button5.AutoRoundedCorners = true;
            guna2Button5.BackColor = Color.Transparent;
            guna2Button5.BorderRadius = 10;
            guna2Button5.CustomizableEdges = customizableEdges19;
            guna2Button5.DisabledState.BorderColor = Color.DarkGray;
            guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button5.FillColor = Color.White;
            guna2Button5.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button5.ForeColor = Color.White;
            guna2Button5.Location = new Point(1214, 12);
            guna2Button5.Name = "guna2Button5";
            guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2Button5.Size = new Size(23, 23);
            guna2Button5.TabIndex = 3;
            guna2Button5.Click += guna2Button5_Click;
            // 
            // guna2Panel1
            // 
            guna2Panel1.Controls.Add(lblUser);
            guna2Panel1.Controls.Add(guna2Button3);
            guna2Panel1.Controls.Add(guna2Button5);
            guna2Panel1.Controls.Add(guna2Button4);
            guna2Panel1.CustomizableEdges = customizableEdges21;
            guna2Panel1.Dock = DockStyle.Top;
            guna2Panel1.Location = new Point(137, 0);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges22;
            guna2Panel1.Size = new Size(1307, 40);
            guna2Panel1.TabIndex = 4;
            // 
            // lblUser
            // 
            lblUser.AutoSize = true;
            lblUser.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblUser.ForeColor = Color.White;
            lblUser.Location = new Point(21, 9);
            lblUser.Name = "lblUser";
            lblUser.Size = new Size(0, 25);
            lblUser.TabIndex = 4;
            // 
            // guna2Panel2
            // 
            guna2Panel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            guna2Panel2.AutoScroll = true;
            guna2Panel2.CustomizableEdges = customizableEdges23;
            guna2Panel2.Location = new Point(137, 40);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges24;
            guna2Panel2.Size = new Size(1307, 773);
            guna2Panel2.TabIndex = 5;
            // 
            // guna2DragControl1
            // 
            guna2DragControl1.DockForm = true;
            guna2DragControl1.DockIndicatorTransparencyValue = 0.6D;
            guna2DragControl1.TargetControl = guna2Panel1;
            guna2DragControl1.UseTransparentDrag = true;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            ClientSize = new Size(1444, 813);
            Controls.Add(guna2Panel2);
            Controls.Add(guna2Panel1);
            Controls.Add(guna2CustomGradientPanel1);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainForm";
            Load += MainForm_Load;
            guna2CustomGradientPanel1.ResumeLayout(false);
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2Button btnHome;
        private Guna.UI2.WinForms.Guna2Button btnCustomer;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Label lblUser;
    }
}