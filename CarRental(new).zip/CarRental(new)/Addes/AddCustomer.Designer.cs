﻿namespace CarRental.Addes
{
    partial class btnBrowse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(btnBrowse));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            txtFname = new Guna.UI2.WinForms.Guna2TextBox();
            txtSname = new Guna.UI2.WinForms.Guna2TextBox();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            txtPhone = new Guna.UI2.WinForms.Guna2TextBox();
            txtUname = new Guna.UI2.WinForms.Guna2TextBox();
            txtPass = new Guna.UI2.WinForms.Guna2TextBox();
            txtAddress = new RichTextBox();
            label1 = new Label();
            label2 = new Label();
            btnLogin = new Guna.UI2.WinForms.Guna2Button();
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2MessageDialog1 = new Guna.UI2.WinForms.Guna2MessageDialog();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2Panel1.SuspendLayout();
            guna2Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.Controls.Add(guna2PictureBox1);
            guna2Panel1.Controls.Add(label2);
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges3;
            guna2Panel1.Controls.SetChildIndex(label2, 0);
            guna2Panel1.Controls.SetChildIndex(guna2PictureBox1, 0);
            // 
            // guna2Panel2
            // 
            guna2Panel2.Controls.Add(btnLogin);
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges6;
            // 
            // txtFname
            // 
            txtFname.Animated = true;
            txtFname.AutoRoundedCorners = true;
            txtFname.BorderColor = Color.FromArgb(10, 123, 165);
            txtFname.BorderRadius = 17;
            txtFname.BorderThickness = 2;
            txtFname.CustomizableEdges = customizableEdges7;
            txtFname.DefaultText = "";
            txtFname.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtFname.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtFname.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtFname.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtFname.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFname.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtFname.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFname.Location = new Point(69, 136);
            txtFname.Name = "txtFname";
            txtFname.PasswordChar = '\0';
            txtFname.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtFname.PlaceholderText = "First Name";
            txtFname.SelectedText = "";
            txtFname.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtFname.Size = new Size(200, 36);
            txtFname.TabIndex = 2;
            // 
            // txtSname
            // 
            txtSname.Animated = true;
            txtSname.AutoRoundedCorners = true;
            txtSname.BorderColor = Color.FromArgb(10, 123, 165);
            txtSname.BorderRadius = 17;
            txtSname.BorderThickness = 2;
            txtSname.CustomizableEdges = customizableEdges9;
            txtSname.DefaultText = "";
            txtSname.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSname.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSname.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSname.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSname.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSname.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtSname.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSname.Location = new Point(301, 136);
            txtSname.Name = "txtSname";
            txtSname.PasswordChar = '\0';
            txtSname.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtSname.PlaceholderText = "Surname";
            txtSname.SelectedText = "";
            txtSname.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtSname.Size = new Size(200, 36);
            txtSname.TabIndex = 3;
            // 
            // txtEmail
            // 
            txtEmail.Animated = true;
            txtEmail.AutoRoundedCorners = true;
            txtEmail.BorderColor = Color.FromArgb(10, 123, 165);
            txtEmail.BorderRadius = 17;
            txtEmail.BorderThickness = 2;
            txtEmail.CustomizableEdges = customizableEdges11;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(551, 136);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtEmail.PlaceholderText = "Email";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtEmail.Size = new Size(200, 36);
            txtEmail.TabIndex = 4;
            txtEmail.TextChanged += guna2TextBox3_TextChanged;
            // 
            // txtPhone
            // 
            txtPhone.Animated = true;
            txtPhone.AutoRoundedCorners = true;
            txtPhone.BorderColor = Color.FromArgb(10, 123, 165);
            txtPhone.BorderRadius = 17;
            txtPhone.BorderThickness = 2;
            txtPhone.CustomizableEdges = customizableEdges13;
            txtPhone.DefaultText = "";
            txtPhone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPhone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPhone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPhone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Location = new Point(69, 228);
            txtPhone.Name = "txtPhone";
            txtPhone.PasswordChar = '\0';
            txtPhone.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtPhone.PlaceholderText = "Phone Number";
            txtPhone.SelectedText = "";
            txtPhone.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtPhone.Size = new Size(200, 36);
            txtPhone.TabIndex = 5;
            // 
            // txtUname
            // 
            txtUname.Animated = true;
            txtUname.AutoRoundedCorners = true;
            txtUname.BorderColor = Color.FromArgb(10, 123, 165);
            txtUname.BorderRadius = 17;
            txtUname.BorderThickness = 2;
            txtUname.CustomizableEdges = customizableEdges15;
            txtUname.DefaultText = "";
            txtUname.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtUname.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtUname.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtUname.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtUname.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUname.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtUname.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUname.Location = new Point(301, 228);
            txtUname.Name = "txtUname";
            txtUname.PasswordChar = '\0';
            txtUname.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtUname.PlaceholderText = "Username";
            txtUname.SelectedText = "";
            txtUname.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtUname.Size = new Size(200, 36);
            txtUname.TabIndex = 6;
            txtUname.TextChanged += guna2TextBox5_TextChanged;
            // 
            // txtPass
            // 
            txtPass.Animated = true;
            txtPass.AutoRoundedCorners = true;
            txtPass.BorderColor = Color.FromArgb(10, 123, 165);
            txtPass.BorderRadius = 17;
            txtPass.BorderThickness = 2;
            txtPass.CustomizableEdges = customizableEdges17;
            txtPass.DefaultText = "";
            txtPass.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPass.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPass.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPass.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPass.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPass.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPass.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPass.Location = new Point(551, 228);
            txtPass.Name = "txtPass";
            txtPass.PasswordChar = '\0';
            txtPass.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtPass.PlaceholderText = "Password";
            txtPass.SelectedText = "";
            txtPass.ShadowDecoration.CustomizableEdges = customizableEdges18;
            txtPass.Size = new Size(200, 36);
            txtPass.TabIndex = 7;
            // 
            // txtAddress
            // 
            txtAddress.BackColor = Color.FromArgb(10, 123, 165);
            txtAddress.BorderStyle = BorderStyle.None;
            txtAddress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtAddress.Location = new Point(99, 317);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(595, 89);
            txtAddress.TabIndex = 9;
            txtAddress.Text = "";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(195, 299);
            label1.Name = "label1";
            label1.Size = new Size(56, 15);
            label1.TabIndex = 10;
            label1.Text = "ADDRESS";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(137, 35);
            label2.Name = "label2";
            label2.Size = new Size(132, 25);
            label2.TabIndex = 0;
            label2.Text = "Add Customer";
            // 
            // btnLogin
            // 
            btnLogin.AutoRoundedCorners = true;
            btnLogin.BackColor = Color.Transparent;
            btnLogin.BorderRadius = 23;
            btnLogin.CustomizableEdges = customizableEdges4;
            btnLogin.DisabledState.BorderColor = Color.DarkGray;
            btnLogin.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLogin.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLogin.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLogin.FillColor = Color.FromArgb(35, 55, 73);
            btnLogin.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(854, 21);
            btnLogin.Name = "btnLogin";
            btnLogin.ShadowDecoration.CustomizableEdges = customizableEdges5;
            btnLogin.Size = new Size(119, 48);
            btnLogin.TabIndex = 11;
            btnLogin.Text = "Save";
            btnLogin.Click += btnLogin_Click;
            // 
            // guna2PictureBox1
            // 
            guna2PictureBox1.CustomizableEdges = customizableEdges1;
            guna2PictureBox1.Image = (Image)resources.GetObject("guna2PictureBox1.Image");
            guna2PictureBox1.ImageRotate = 0F;
            guna2PictureBox1.Location = new Point(32, 9);
            guna2PictureBox1.Name = "guna2PictureBox1";
            guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2PictureBox1.Size = new Size(97, 75);
            guna2PictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox1.TabIndex = 1;
            guna2PictureBox1.TabStop = false;
            // 
            // guna2MessageDialog1
            // 
            guna2MessageDialog1.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
            guna2MessageDialog1.Caption = null;
            guna2MessageDialog1.Icon = Guna.UI2.WinForms.MessageDialogIcon.None;
            guna2MessageDialog1.Parent = this;
            guna2MessageDialog1.Style = Guna.UI2.WinForms.MessageDialogStyle.Light;
            guna2MessageDialog1.Text = null;
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.Image = (Image)resources.GetObject("guna2CirclePictureBox1.Image");
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(854, 123);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges21;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(137, 151);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2CirclePictureBox1.TabIndex = 11;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // guna2Button1
            // 
            guna2Button1.CustomizableEdges = customizableEdges19;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(854, 299);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2Button1.Size = new Size(137, 35);
            guna2Button1.TabIndex = 12;
            guna2Button1.Text = "Browse";
            guna2Button1.Click += guna2Button1_Click;
            // 
            // btnBrowse
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1017, 554);
            Controls.Add(guna2Button1);
            Controls.Add(guna2CirclePictureBox1);
            Controls.Add(label1);
            Controls.Add(txtAddress);
            Controls.Add(txtPass);
            Controls.Add(txtUname);
            Controls.Add(txtPhone);
            Controls.Add(txtEmail);
            Controls.Add(txtSname);
            Controls.Add(txtFname);
            Name = "btnBrowse";
            Text = "AddCustomer";
            Load += AddCustomer_Load;
            Controls.SetChildIndex(guna2Panel1, 0);
            Controls.SetChildIndex(guna2Panel2, 0);
            Controls.SetChildIndex(txtFname, 0);
            Controls.SetChildIndex(txtSname, 0);
            Controls.SetChildIndex(txtEmail, 0);
            Controls.SetChildIndex(txtPhone, 0);
            Controls.SetChildIndex(txtUname, 0);
            Controls.SetChildIndex(txtPass, 0);
            Controls.SetChildIndex(txtAddress, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(guna2CirclePictureBox1, 0);
            Controls.SetChildIndex(guna2Button1, 0);
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            guna2Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2MessageDialog guna2MessageDialog1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        public Guna.UI2.WinForms.Guna2TextBox txtFname;
        public Guna.UI2.WinForms.Guna2TextBox txtSname;
        public Guna.UI2.WinForms.Guna2TextBox txtEmail;
        public Guna.UI2.WinForms.Guna2TextBox txtPhone;
        public Guna.UI2.WinForms.Guna2TextBox txtUname;
        public Guna.UI2.WinForms.Guna2TextBox txtPass;
        public RichTextBox txtAddress;
        public Guna.UI2.WinForms.Guna2Button btnLogin;
        public Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
    }
}