﻿namespace CarRental.Addes
{
    partial class AddCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddCar));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            txtDescription = new Guna.UI2.WinForms.Guna2TextBox();
            txtDaily = new Guna.UI2.WinForms.Guna2TextBox();
            txtPlate = new Guna.UI2.WinForms.Guna2TextBox();
            txtYear = new Guna.UI2.WinForms.Guna2TextBox();
            txtBrand = new Guna.UI2.WinForms.Guna2TextBox();
            btnLogin = new Guna.UI2.WinForms.Guna2Button();
            cbCat = new Guna.UI2.WinForms.Guna2ComboBox();
            cbFuel = new Guna.UI2.WinForms.Guna2ComboBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            label5 = new Label();
            label7 = new Label();
            label8 = new Label();
            cbAvail = new Guna.UI2.WinForms.Guna2CheckBox();
            txtModel = new Guna.UI2.WinForms.Guna2TextBox();
            label9 = new Label();
            guna2MessageDialog1 = new Guna.UI2.WinForms.Guna2MessageDialog();
            guna2Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges1;
            guna2Panel1.Size = new Size(946, 90);
            // 
            // guna2Panel2
            // 
            guna2Panel2.Controls.Add(btnLogin);
            guna2Panel2.Location = new Point(0, 390);
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Panel2.Size = new Size(946, 90);
            // 
            // guna2Button1
            // 
            guna2Button1.CustomizableEdges = customizableEdges5;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(788, 288);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Button1.Size = new Size(137, 35);
            guna2Button1.TabIndex = 21;
            guna2Button1.Text = "Browse";
            guna2Button1.Click += guna2Button1_Click;
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.Image = (Image)resources.GetObject("guna2CirclePictureBox1.Image");
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(788, 113);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges7;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(137, 151);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2CirclePictureBox1.TabIndex = 19;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // txtDescription
            // 
            txtDescription.Animated = true;
            txtDescription.AutoRoundedCorners = true;
            txtDescription.BorderColor = Color.FromArgb(10, 123, 165);
            txtDescription.BorderRadius = 69;
            txtDescription.BorderThickness = 2;
            txtDescription.CustomizableEdges = customizableEdges8;
            txtDescription.DefaultText = "";
            txtDescription.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtDescription.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtDescription.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtDescription.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtDescription.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDescription.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtDescription.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDescription.Location = new Point(306, 207);
            txtDescription.Name = "txtDescription";
            txtDescription.PasswordChar = '\0';
            txtDescription.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtDescription.PlaceholderText = "";
            txtDescription.SelectedText = "";
            txtDescription.ShadowDecoration.CustomizableEdges = customizableEdges9;
            txtDescription.Size = new Size(418, 140);
            txtDescription.TabIndex = 18;
            // 
            // txtDaily
            // 
            txtDaily.Animated = true;
            txtDaily.AutoRoundedCorners = true;
            txtDaily.BorderColor = Color.FromArgb(10, 123, 165);
            txtDaily.BorderRadius = 17;
            txtDaily.BorderThickness = 2;
            txtDaily.CustomizableEdges = customizableEdges10;
            txtDaily.DefaultText = "";
            txtDaily.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtDaily.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtDaily.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtDaily.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtDaily.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDaily.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtDaily.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDaily.Location = new Point(588, 120);
            txtDaily.Name = "txtDaily";
            txtDaily.PasswordChar = '\0';
            txtDaily.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtDaily.PlaceholderText = "£";
            txtDaily.SelectedText = "";
            txtDaily.ShadowDecoration.CustomizableEdges = customizableEdges11;
            txtDaily.Size = new Size(117, 36);
            txtDaily.TabIndex = 16;
            txtDaily.TextChanged += txtDaily_TextChanged;
            txtDaily.KeyPress += txtDaily_KeyPress;
            // 
            // txtPlate
            // 
            txtPlate.Animated = true;
            txtPlate.AutoRoundedCorners = true;
            txtPlate.BorderColor = Color.FromArgb(10, 123, 165);
            txtPlate.BorderRadius = 17;
            txtPlate.BorderThickness = 2;
            txtPlate.CustomizableEdges = customizableEdges12;
            txtPlate.DefaultText = "";
            txtPlate.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPlate.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPlate.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPlate.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPlate.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPlate.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPlate.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPlate.Location = new Point(383, 120);
            txtPlate.Name = "txtPlate";
            txtPlate.PasswordChar = '\0';
            txtPlate.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtPlate.PlaceholderText = "";
            txtPlate.SelectedText = "";
            txtPlate.ShadowDecoration.CustomizableEdges = customizableEdges13;
            txtPlate.Size = new Size(165, 36);
            txtPlate.TabIndex = 15;
            // 
            // txtYear
            // 
            txtYear.Animated = true;
            txtYear.AutoRoundedCorners = true;
            txtYear.BorderColor = Color.FromArgb(10, 123, 165);
            txtYear.BorderRadius = 17;
            txtYear.BorderThickness = 2;
            txtYear.CustomizableEdges = customizableEdges14;
            txtYear.DefaultText = "";
            txtYear.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtYear.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtYear.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtYear.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtYear.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtYear.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtYear.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtYear.Location = new Point(276, 120);
            txtYear.Name = "txtYear";
            txtYear.PasswordChar = '\0';
            txtYear.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtYear.PlaceholderText = "";
            txtYear.SelectedText = "";
            txtYear.ShadowDecoration.CustomizableEdges = customizableEdges15;
            txtYear.Size = new Size(74, 36);
            txtYear.TabIndex = 14;
            txtYear.KeyPress += txtYear_KeyPress;
            // 
            // txtBrand
            // 
            txtBrand.Animated = true;
            txtBrand.AutoRoundedCorners = true;
            txtBrand.BorderColor = Color.FromArgb(10, 123, 165);
            txtBrand.BorderRadius = 17;
            txtBrand.BorderThickness = 2;
            txtBrand.CustomizableEdges = customizableEdges16;
            txtBrand.DefaultText = "";
            txtBrand.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtBrand.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtBrand.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtBrand.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtBrand.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtBrand.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtBrand.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtBrand.Location = new Point(36, 120);
            txtBrand.Name = "txtBrand";
            txtBrand.PasswordChar = '\0';
            txtBrand.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtBrand.PlaceholderText = "";
            txtBrand.SelectedText = "";
            txtBrand.ShadowDecoration.CustomizableEdges = customizableEdges17;
            txtBrand.Size = new Size(104, 36);
            txtBrand.TabIndex = 13;
            // 
            // btnLogin
            // 
            btnLogin.AutoRoundedCorners = true;
            btnLogin.BackColor = Color.Transparent;
            btnLogin.BorderRadius = 23;
            btnLogin.CustomizableEdges = customizableEdges2;
            btnLogin.DisabledState.BorderColor = Color.DarkGray;
            btnLogin.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLogin.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLogin.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLogin.FillColor = Color.FromArgb(35, 55, 73);
            btnLogin.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(806, 30);
            btnLogin.Name = "btnLogin";
            btnLogin.ShadowDecoration.CustomizableEdges = customizableEdges3;
            btnLogin.Size = new Size(119, 48);
            btnLogin.TabIndex = 20;
            btnLogin.Text = "Save";
            btnLogin.Click += btnLogin_Click;
            // 
            // cbCat
            // 
            cbCat.BackColor = Color.Transparent;
            cbCat.CustomizableEdges = customizableEdges18;
            cbCat.DrawMode = DrawMode.OwnerDrawFixed;
            cbCat.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCat.FocusedColor = Color.FromArgb(94, 148, 255);
            cbCat.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbCat.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cbCat.ForeColor = Color.FromArgb(68, 88, 112);
            cbCat.ItemHeight = 30;
            cbCat.Items.AddRange(new object[] { "Sedan", "SUV", "Hatchback" });
            cbCat.Location = new Point(36, 189);
            cbCat.Name = "cbCat";
            cbCat.ShadowDecoration.CustomizableEdges = customizableEdges19;
            cbCat.Size = new Size(104, 36);
            cbCat.StartIndex = 0;
            cbCat.TabIndex = 22;
            cbCat.SelectedIndexChanged += guna2ComboBox1_SelectedIndexChanged;
            // 
            // cbFuel
            // 
            cbFuel.BackColor = Color.Transparent;
            cbFuel.CustomizableEdges = customizableEdges20;
            cbFuel.DrawMode = DrawMode.OwnerDrawFixed;
            cbFuel.DropDownStyle = ComboBoxStyle.DropDownList;
            cbFuel.FocusedColor = Color.FromArgb(94, 148, 255);
            cbFuel.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbFuel.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cbFuel.ForeColor = Color.FromArgb(68, 88, 112);
            cbFuel.ItemHeight = 30;
            cbFuel.Items.AddRange(new object[] { "gasoline", "diesel", "LPG" });
            cbFuel.Location = new Point(171, 189);
            cbFuel.Name = "cbFuel";
            cbFuel.ShadowDecoration.CustomizableEdges = customizableEdges21;
            cbFuel.Size = new Size(104, 36);
            cbFuel.TabIndex = 23;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.White;
            label1.Location = new Point(53, 102);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 24;
            label1.Text = "Brand";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.White;
            label2.Location = new Point(294, 102);
            label2.Name = "label2";
            label2.Size = new Size(29, 15);
            label2.TabIndex = 25;
            label2.Text = "Year";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.White;
            label3.Location = new Point(399, 102);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 26;
            label3.Text = "Plate";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.White;
            label4.Location = new Point(446, 189);
            label4.Name = "label4";
            label4.Size = new Size(111, 15);
            label4.TabIndex = 27;
            label4.Text = "Description for User";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.White;
            label6.Location = new Point(597, 102);
            label6.Name = "label6";
            label6.Size = new Size(95, 15);
            label6.TabIndex = 29;
            label6.Text = "Daily Rental Rate";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.White;
            label5.Location = new Point(827, 113);
            label5.Name = "label5";
            label5.Size = new Size(61, 15);
            label5.TabIndex = 30;
            label5.Text = "Car Image";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = Color.White;
            label7.Location = new Point(36, 171);
            label7.Name = "label7";
            label7.Size = new Size(55, 15);
            label7.TabIndex = 31;
            label7.Text = "Category";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.White;
            label8.Location = new Point(171, 171);
            label8.Name = "label8";
            label8.Size = new Size(56, 15);
            label8.TabIndex = 32;
            label8.Text = "Fuel Type";
            // 
            // cbAvail
            // 
            cbAvail.AutoSize = true;
            cbAvail.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbAvail.CheckedState.BorderRadius = 0;
            cbAvail.CheckedState.BorderThickness = 0;
            cbAvail.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            cbAvail.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            cbAvail.ForeColor = SystemColors.Control;
            cbAvail.Location = new Point(48, 274);
            cbAvail.Name = "cbAvail";
            cbAvail.Size = new Size(104, 25);
            cbAvail.TabIndex = 33;
            cbAvail.Text = "AVAILABLE\r\n";
            cbAvail.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            cbAvail.UncheckedState.BorderRadius = 0;
            cbAvail.UncheckedState.BorderThickness = 0;
            cbAvail.UncheckedState.FillColor = Color.FromArgb(125, 137, 149);
            // 
            // txtModel
            // 
            txtModel.Animated = true;
            txtModel.AutoRoundedCorners = true;
            txtModel.BorderColor = Color.FromArgb(10, 123, 165);
            txtModel.BorderRadius = 17;
            txtModel.BorderThickness = 2;
            txtModel.CustomizableEdges = customizableEdges22;
            txtModel.DefaultText = "";
            txtModel.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtModel.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtModel.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtModel.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtModel.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtModel.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtModel.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtModel.Location = new Point(146, 120);
            txtModel.Name = "txtModel";
            txtModel.PasswordChar = '\0';
            txtModel.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtModel.PlaceholderText = "";
            txtModel.SelectedText = "";
            txtModel.ShadowDecoration.CustomizableEdges = customizableEdges23;
            txtModel.Size = new Size(105, 36);
            txtModel.TabIndex = 34;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = Color.White;
            label9.Location = new Point(158, 102);
            label9.Name = "label9";
            label9.Size = new Size(41, 15);
            label9.TabIndex = 35;
            label9.Text = "Model";
            // 
            // guna2MessageDialog1
            // 
            guna2MessageDialog1.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
            guna2MessageDialog1.Caption = null;
            guna2MessageDialog1.Icon = Guna.UI2.WinForms.MessageDialogIcon.None;
            guna2MessageDialog1.Parent = null;
            guna2MessageDialog1.Style = Guna.UI2.WinForms.MessageDialogStyle.Default;
            guna2MessageDialog1.Text = null;
            // 
            // AddCar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(946, 480);
            Controls.Add(label9);
            Controls.Add(txtModel);
            Controls.Add(cbAvail);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cbFuel);
            Controls.Add(cbCat);
            Controls.Add(guna2Button1);
            Controls.Add(guna2CirclePictureBox1);
            Controls.Add(txtDescription);
            Controls.Add(txtDaily);
            Controls.Add(txtPlate);
            Controls.Add(txtYear);
            Controls.Add(txtBrand);
            Name = "AddCar";
            Text = "AddCar";
            Load += AddCar_Load;
            Controls.SetChildIndex(txtBrand, 0);
            Controls.SetChildIndex(txtYear, 0);
            Controls.SetChildIndex(txtPlate, 0);
            Controls.SetChildIndex(txtDaily, 0);
            Controls.SetChildIndex(txtDescription, 0);
            Controls.SetChildIndex(guna2CirclePictureBox1, 0);
            Controls.SetChildIndex(guna2Button1, 0);
            Controls.SetChildIndex(cbCat, 0);
            Controls.SetChildIndex(cbFuel, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(label2, 0);
            Controls.SetChildIndex(label3, 0);
            Controls.SetChildIndex(label4, 0);
            Controls.SetChildIndex(label6, 0);
            Controls.SetChildIndex(label5, 0);
            Controls.SetChildIndex(guna2Panel1, 0);
            Controls.SetChildIndex(guna2Panel2, 0);
            Controls.SetChildIndex(label7, 0);
            Controls.SetChildIndex(label8, 0);
            Controls.SetChildIndex(cbAvail, 0);
            Controls.SetChildIndex(txtModel, 0);
            Controls.SetChildIndex(label9, 0);
            guna2Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btnLogin;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox txtDescription;
        private Guna.UI2.WinForms.Guna2TextBox txtDaily;
        private Guna.UI2.WinForms.Guna2TextBox txtPlate;
        private Guna.UI2.WinForms.Guna2TextBox txtYear;
        private Guna.UI2.WinForms.Guna2TextBox txtBrand;
        private Guna.UI2.WinForms.Guna2ComboBox cbCat;
        private Guna.UI2.WinForms.Guna2ComboBox cbFuel;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label5;
        private Label label7;
        private Label label8;
        private Guna.UI2.WinForms.Guna2CheckBox cbAvail;
        private Guna.UI2.WinForms.Guna2TextBox txtModel;
        private Label label9;
        private Guna.UI2.WinForms.Guna2MessageDialog guna2MessageDialog1;
    }
}