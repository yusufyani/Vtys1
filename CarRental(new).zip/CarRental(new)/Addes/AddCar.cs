﻿using CarRental.Samples;
using Guna.UI2.WinForms;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Addes
{
    public partial class AddCar : SampleAdd
    {
        public AddCar()
        {
            InitializeComponent();
        }

        int id = 0;
        public int cID = 0;

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            // Önce kullanıcının seçtiği kategoriyi alın
            int selectedCategoryId = Convert.ToInt32(cbCat.SelectedValue); // Burada cbCat, kullanıcının seçtiği kategori için bir ComboBox veya benzeri bir kontroldür.

            // Ardından CategoryID değerini kullanarak sorgunuzu oluşturun
            string qry = "";
            if (id == 0) // Insert
            {
                qry = "Insert into Vehicles (BrandModel, PlateNumber, Year, FuelType, DailyRentalRate, Description, Availability, CatID, vehicleIMG, eImage1, eImage2, eImage3) " +
                      "Values (@Brand, @Plate, @Year, @Fuel, @DailyRate, @Description, @Available, @Catid, @img, @eimg1, @eimg2, @eimg3)";
            }
            else // Update
            {
                qry = "Update Vehicles Set BrandModel = @Brand, PlateNumber = @Plate, Year = @Year, FuelType = @Fuel, DailyRentalRate = @DailyRate, " +
                      "Description = @Description, Availability = @Available, CatID = @Catid, vehicleIMG = @img, eImage1 = @eimg1, eImage2 = @eimg2, eImage3 = @eimg3 " +
                      "Where VehicleID = @id";
            }

            Hashtable ht = new Hashtable();
            ht.Add("@id", id);
            ht.Add("@Brand", txtBrand.Text + "/" + txtModel.Text);
            ht.Add("@Plate", txtPlate.Text);
            ht.Add("@Year", txtYear.Text);
            ht.Add("@Fuel", Convert.ToInt32(cbFuel.SelectedValue));
            ht.Add("@DailyRate", txtDaily.Text);
            ht.Add("@Description", txtDescription.Text);
            ht.Add("@Available", cbAvail.Checked ? 1 : 0);
            ht.Add("@Catid", Convert.ToInt32(cbCat.SelectedValue)); // Seçilen kategoriye karşılık gelen CategoryID değeri  
            ht.Add("@img", imageByteArray);
            ht.Add("@eimg1", imageByteArray);
            ht.Add("@eimg2", imageByteArray);
            ht.Add("@eimg3", imageByteArray);

            if (MainClass.SQl(qry, ht) > 0)
            {
                guna2MessageDialog1.Show("Kayıt işlemi Başırılı");
                id = 0;
                txtBrand.Text = "";
                txtModel.Text = "";
            }

        }

        string filePath;
        byte[] imageByteArray;

        private void txtYear_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }

            if (txtYear.Text.Length >= 4 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void txtDaily_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDaily_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }

            if (txtDaily.Text.Length >= 5 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void forUpdateLoadData()
        {
            string qry = @"Select * From Vehicles Where VehicleID = " + id + "";
            SqlCommand cmd = new SqlCommand(qry, MainClass.con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Byte[] imageArray = (byte[])(dt.Rows[0]["dgvimg"]);
                byte[] imageByteArray = imageArray;
                guna2CirclePictureBox1.Image = Image.FromStream(new MemoryStream(imageArray));
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Images(.jpg, .png)|*.png;*.jpg";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                filePath = ofd.FileName;
                guna2CirclePictureBox1.Image = new Bitmap(filePath);

                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    imageByteArray = new byte[fs.Length];
                    fs.Read(imageByteArray, 0, (int)fs.Length);
                }
            }
        }

        private void AddCar_Load(object sender, EventArgs e)
        {
            string qry = "SELECT  CategoryName 'name', CategoryID 'id' FROM VehicleCategories";
            MainClass.CBFill(qry, cbCat);

            if (cID > 0) // update için
            {
                cbCat.SelectedValue = cID;

            }

            if (id > 0)
            {
                forUpdateLoadData();
            }
        }
    }
}
