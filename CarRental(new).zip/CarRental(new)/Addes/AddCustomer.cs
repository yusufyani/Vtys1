﻿using CarRental.Samples;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Guna.UI2.Native.WinApi;
using System.Xml.Linq;
using System.Data.SqlClient;
using Guna.UI2.WinForms;

namespace CarRental.Addes
{
    public partial class btnBrowse : SampleAdd
    {
        public btnBrowse()
        {
            InitializeComponent();
        }

        public int id = 0;

        private void AddCustomer_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string qry = "";
            if (id == 0) // Insert
            {
                qry = "Insert into Customers Values (@Fname, @Sname, @Email, @Phone, @username, @Password, @Address, @img)";
            }
            else // Update
            {
                qry = "Update Customers Set cFirstName = @FName, cLastName = @Sname, cEmail = @Email, cPhone = @Phone, cUsername = @username, cPass = @Password, cAddress = @Address, customerIMG = @img Where CustomerID = @id ";
            }


            Hashtable ht = new Hashtable();
            ht.Add("@id", id);
            ht.Add("@FName", txtFname.Text);
            ht.Add("@Sname", txtSname.Text);
            ht.Add("@Email", txtEmail.Text);
            ht.Add("@Phone", txtPhone.Text);
            ht.Add("@username", txtUname.Text);
            ht.Add("@Password", txtPass.Text);
            ht.Add("@Address", txtAddress.Text);
            ht.Add("@img", imageByteArray);


            if (MainClass.SQl(qry, ht) > 0)
            {
                guna2MessageDialog1.Show("Kayıt işlemi Başırılı");
                id = 0;
                txtFname.Text = "";
                txtSname.Text = "";
            }
        }

        private void forUpdateLoadData()
        {
            string qry = @"Select * From Customers Where CustomerID = " + id + "";
            SqlCommand cmd = new SqlCommand(qry, MainClass.con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                txtFname.Text = dt.Rows[0]["cFirstName"].ToString();
                txtSname.Text = dt.Rows[0]["cLastName"].ToString();

                Byte[] imageArray = (byte[])(dt.Rows[0]["dgvimg"]);
                byte[] imageByteArray = imageArray;
                guna2CirclePictureBox1.Image = Image.FromStream(new MemoryStream(imageArray));
            }
        }


        private void guna2TextBox3_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnExit_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox5_TextChanged(object sender, EventArgs e)
        {

        }
        string filePath;
        byte[] imageByteArray;
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Images(.jpg, .png)|*.png;*.jpg";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                filePath = ofd.FileName;
                guna2CirclePictureBox1.Image = new Bitmap(filePath);

                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    imageByteArray = new byte[fs.Length];
                    fs.Read(imageByteArray, 0, (int)fs.Length);
                }
            }
        }

    }
}
