﻿using CarRental.Samples;
using Guna.UI2.WinForms;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Addes
{

    public partial class AddBooking : SampleAdd
    {
        decimal netAmount = 0.00m;
        public AddBooking()
        {
            InitializeComponent();
        }
        int id = 0;
        int cID = 0;
        int vID = 0;

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string qry2 = "SELECT  CFirstName 'name', CustomerID 'id' FROM Customers";
            MainClass.CBFill(qry2, guna2ComboBox1);
            string qry1 = "SELECT  BrandModel 'name', VehicleID 'id' FROM Vehicles";
            MainClass.CBFill(qry1, guna2ComboBox2);
            CalculateNetAmount();
            string qry = "";
            if (id == 0) // Insert
            {
                qry = "Insert into Reservations Values (@resDate, @DoS, @DoE, @Customer, @VehicleID, @NetAmount)";
            }
            else // Update
            {
                qry = "Update Reservations Set ReservationDate = @resDate, RentalStartDate = @DoS, RentalEndDate = @DoE, CustomerID = @Customer, VehicleID = @Vehicle, NetAmount = @NetAmount";
            }

            Hashtable ht = new Hashtable();
            ht.Add("@id", id);
            ht.Add("@resDate", DateTime.Now);
            ht.Add("@DoS", guna2DateTimePicker1.Value.Date);
            ht.Add("@DoE", guna2DateTimePicker2.Value.Date);
            ht.Add("@Customer", Convert.ToInt32(guna2ComboBox1.SelectedValue));
            ht.Add("@VehicleID", Convert.ToInt32(guna2ComboBox2.SelectedValue));
            ht.Add("@NetAmount", netAmount);

            if (MainClass.SQl(qry, ht) > 0 && netAmount > 0)
            {
                guna2MessageDialog1.Show("Kayıt işlemi Başarılı");
                id = 0;
            }
            else
            {
                guna2MessageDialog1.Show("Hatalı deneme!");
            }
        }


        private void forUpdateLoadData()
        {
            CalculateNetAmount();
            string qry = @"Select * From Reservations Where ReservationID = " + id + "";
            SqlCommand cmd = new SqlCommand(qry, MainClass.con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
        }


        private void AddBooking_Load(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            lblToday.Text = dt.ToString();
            CalculateNetAmount();
            string qry = "SELECT  CFirstName 'name', CustomerID 'id' FROM Customers";
            MainClass.CBFill(qry, guna2ComboBox1);
            string qry1 = "SELECT  BrandModel 'name', VehicleID 'id' FROM Vehicles";
            MainClass.CBFill(qry1, guna2ComboBox2);

            if (cID > 0) // update 
            {
                guna2ComboBox1.SelectedValue = cID;

            }

            if (vID > 0) // update
            {
                guna2ComboBox2.SelectedValue = vID;

            }

            if (id > 0)
            {
                forUpdateLoadData();
            }

        }

        private void CalculateNetAmount()
        {
            DateTime startDate = guna2DateTimePicker1.Value.Date;
            DateTime endDate = guna2DateTimePicker2.Value.Date;

            TimeSpan span = endDate - startDate;
            int rentalDays = span.Days;

            // Burada VehicleID'yi kullanarak DailyRentalRate'i veritabanından almalısınız.
            int vehicleID = Convert.ToInt32(guna2ComboBox2.SelectedValue);
            decimal dailyRentalRate = GetDailyRentalRate(vehicleID); // Bu fonksiyonu oluşturmanız gerekecektir.

            // NetAmount'i hesapla
            netAmount = rentalDays * dailyRentalRate;

            label3.Text = "Tenancy: " + rentalDays.ToString();
            lblAmount.Text = netAmount.ToString("C");
        }

        // VehicleID ile ilgili günlük kira ücretini veritabanından almak için kullanabileceğiniz örnek bir fonksiyon
        private decimal GetDailyRentalRate(int vehicleID)
        {
            decimal dailyRentalRate = 0.00m;

            // Burada veritabanından DailyRentalRate'i almak için gerekli SQL sorgusunu çalıştırmalısınız.
            string qry = "SELECT DailyRentalRate FROM Vehicles WHERE VehicleID = @VehicleID";
            Hashtable ht = new Hashtable();
            ht.Add("@VehicleID", vehicleID);

            // Veritabanı sorgusunu çalıştırın ve sonucu dailyRentalRate değişkenine atayın.

            // Örnek bir SQL sorgusu çalıştırma işlemi:
            dailyRentalRate = MainClass.ExecuteScalar<decimal>(qry, ht);

            return dailyRentalRate;
        }




        private void label3_Click(object sender, EventArgs e)
        {
            DateTime E = guna2DateTimePicker1.Value;
            DateTime S = guna2DateTimePicker2.Value;

            TimeSpan span = S - E;
            int rentalDays = span.Days + 1;

            label3.Text = "Tenancy: " + rentalDays.ToString();
        }


        private void guna2DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            CalculateNetAmount();
        }

        private void guna2DateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            CalculateNetAmount();
        }

        private void guna2ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            CalculateNetAmount();
        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            CalculateNetAmount();
        }
    }
}
