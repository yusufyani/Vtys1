﻿using CarRental.Details.buttons;
using CarRental.Samples;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Addes
{
    public partial class AddDocument : SampleAdd
    {
        private Documents documentsForm;

        public AddDocument(Documents documents)
        {
            InitializeComponent();
            this.documentsForm = documents;
        }

        public class Document
        {
            public string FileName { get; set; }
            public string Address { get; set; }
        }

        private MainForm mainForm;



        private void txtDocAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Tüm Dosyalar (*.*)|*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.Multiselect = false;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string selectedFilePath = openFileDialog.FileName;
                txtDocAddress.Text = selectedFilePath;
            }
        }


        private void txtFileName_TextChanged(object sender, EventArgs e)
        {

        }

        private List<Document> documents = new List<Document>();

        private void btnSave_Click(object sender, EventArgs e)
        {
            string fileName = txtFileName.Text;
            string address = txtDocAddress.Text;

            Document newDocument = new Document
            {
                FileName = fileName,
                Address = address
            };

            documents.Add(newDocument);

            if (documentsForm != null)
            {
                documentsForm.UpdateDataGridView(documents);
            }

            this.Close();
        }

    }
}
