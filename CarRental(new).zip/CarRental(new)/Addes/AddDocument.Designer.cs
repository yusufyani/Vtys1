﻿namespace CarRental.Addes
{
    partial class AddDocument
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            txtDocAddress = new Guna.UI2.WinForms.Guna2TextBox();
            txtFileName = new Guna.UI2.WinForms.Guna2TextBox();
            btnBrowse = new Guna.UI2.WinForms.Guna2Button();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            guna2Panel2.SuspendLayout();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges1;
            guna2Panel1.Size = new Size(901, 52);
            // 
            // guna2Panel2
            // 
            guna2Panel2.Controls.Add(btnSave);
            guna2Panel2.Location = new Point(0, 277);
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Panel2.Size = new Size(901, 56);
            // 
            // txtDocAddress
            // 
            txtDocAddress.Animated = true;
            txtDocAddress.AutoRoundedCorners = true;
            txtDocAddress.BorderColor = Color.FromArgb(10, 123, 165);
            txtDocAddress.BorderRadius = 17;
            txtDocAddress.BorderThickness = 2;
            txtDocAddress.CustomizableEdges = customizableEdges5;
            txtDocAddress.DefaultText = "";
            txtDocAddress.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtDocAddress.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtDocAddress.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtDocAddress.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtDocAddress.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDocAddress.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtDocAddress.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDocAddress.Location = new Point(40, 83);
            txtDocAddress.Name = "txtDocAddress";
            txtDocAddress.PasswordChar = '\0';
            txtDocAddress.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtDocAddress.PlaceholderText = "Document Address";
            txtDocAddress.SelectedText = "";
            txtDocAddress.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtDocAddress.Size = new Size(676, 36);
            txtDocAddress.TabIndex = 12;
            txtDocAddress.TextChanged += txtDocAddress_TextChanged;
            // 
            // txtFileName
            // 
            txtFileName.Animated = true;
            txtFileName.AutoRoundedCorners = true;
            txtFileName.BorderColor = Color.FromArgb(10, 123, 165);
            txtFileName.BorderRadius = 17;
            txtFileName.BorderThickness = 2;
            txtFileName.CustomizableEdges = customizableEdges7;
            txtFileName.DefaultText = "";
            txtFileName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtFileName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtFileName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtFileName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtFileName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFileName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtFileName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFileName.Location = new Point(40, 153);
            txtFileName.Name = "txtFileName";
            txtFileName.PasswordChar = '\0';
            txtFileName.PlaceholderForeColor = Color.FromArgb(163, 190, 200);
            txtFileName.PlaceholderText = "File Name";
            txtFileName.SelectedText = "";
            txtFileName.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtFileName.Size = new Size(200, 36);
            txtFileName.TabIndex = 13;
            txtFileName.TextChanged += txtFileName_TextChanged;
            // 
            // btnBrowse
            // 
            btnBrowse.CustomizableEdges = customizableEdges9;
            btnBrowse.DisabledState.BorderColor = Color.DarkGray;
            btnBrowse.DisabledState.CustomBorderColor = Color.DarkGray;
            btnBrowse.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnBrowse.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnBrowse.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnBrowse.ForeColor = Color.White;
            btnBrowse.Location = new Point(752, 84);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnBrowse.Size = new Size(137, 35);
            btnBrowse.TabIndex = 14;
            btnBrowse.Text = "Browse";
            btnBrowse.Click += btnBrowse_Click;
            // 
            // btnSave
            // 
            btnSave.AutoRoundedCorners = true;
            btnSave.BackColor = Color.Transparent;
            btnSave.BorderRadius = 19;
            btnSave.CustomizableEdges = customizableEdges2;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(35, 55, 73);
            btnSave.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(752, 10);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges3;
            btnSave.Size = new Size(119, 40);
            btnSave.TabIndex = 12;
            btnSave.Text = "Save";
            btnSave.Click += btnSave_Click;
            // 
            // AddDocument
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(901, 333);
            Controls.Add(btnBrowse);
            Controls.Add(txtFileName);
            Controls.Add(txtDocAddress);
            Name = "AddDocument";
            Text = "AddDocument";
            Controls.SetChildIndex(txtDocAddress, 0);
            Controls.SetChildIndex(txtFileName, 0);
            Controls.SetChildIndex(guna2Panel1, 0);
            Controls.SetChildIndex(guna2Panel2, 0);
            Controls.SetChildIndex(btnBrowse, 0);
            guna2Panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtDocAddress;
        private Guna.UI2.WinForms.Guna2TextBox txtFileName;
        private Guna.UI2.WinForms.Guna2Button btnBrowse;
        private Guna.UI2.WinForms.Guna2Button btnSave;
    }
}