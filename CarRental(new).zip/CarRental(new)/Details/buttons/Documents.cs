﻿using CarRental.Addes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Details.buttons
{
    public partial class Documents : Form
    {
        public Documents()
        {
            InitializeComponent();
        }

        private List<AddDocument.Document> documents = new List<AddDocument.Document>();
        public void UpdateDataGridView(List<AddDocument.Document> documents)
        {
            guna2DataGridView1.DataSource = null;
            guna2DataGridView1.DataSource = documents;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddDocument addDocumentForm = new AddDocument(this); // Ana formu AddDocument formuna referans olarak iletiyoruz
            addDocumentForm.ShowDialog();
            // DataGridView'i güncellemek için aşağıdaki satırı ekleyin
            UpdateDataGridView(documents);
        }

        private void Documents_Load(object sender, EventArgs e)
        {

        }
    }
}
