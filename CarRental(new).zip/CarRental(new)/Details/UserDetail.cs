﻿using CarRental.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Details
{
    public partial class UserDetail : SampleModel
    {
        public UserDetail(string customerName, Image customerImage, string customerPhone, string customerEmail, string customerAddress)

        {
            InitializeComponent();
            lblCustomerName.Text = customerName;
            CustomerImage.Image = customerImage;
            CustomerImage.SizeMode = PictureBoxSizeMode.Zoom;
            txtCustomerPhone.Text = customerPhone;
            lblCustomerEmail.Text = customerEmail;
            lblcustomerAddress.Text = customerAddress;
        }
        public void AddControlls1(Form f)
        {
            guna2Panel6.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            guna2Panel6.Controls.Add(f);
            f.Show();
        }


        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblCustomerPhone_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            Customers customer = new Customers();

            MainForm mainForm = Application.OpenForms.OfType<MainForm>().FirstOrDefault();
            if (mainForm != null)
            {
                mainForm.AddControlls(customer);
            }
        }

        private void btnBooking_Click(object sender, EventArgs e)
        {

        }

        private void btnDocument_Click(object sender, EventArgs e)
        {
            AddControlls1(new buttons.Documents());
        }
    }
}
