﻿namespace CarRental.Details
{
    partial class UserDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserDetail));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            CustomerImage = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            lblcustomerAddress = new Label();
            lblCustomerEmail = new Label();
            txtCustomerPhone = new Label();
            lblEmail = new Label();
            guna2vSeparator2 = new Guna.UI2.WinForms.Guna2VSeparator();
            lblAddress = new Label();
            guna2vSeparator1 = new Guna.UI2.WinForms.Guna2VSeparator();
            lblCustomerPhone = new Label();
            btnSummary = new Guna.UI2.WinForms.Guna2Button();
            btnBooking = new Guna.UI2.WinForms.Guna2Button();
            btnNote = new Guna.UI2.WinForms.Guna2Button();
            btnDocument = new Guna.UI2.WinForms.Guna2Button();
            btnDeposits = new Guna.UI2.WinForms.Guna2Button();
            guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            lblCustomerName = new Label();
            guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            guna2CustomGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)CustomerImage).BeginInit();
            guna2Panel2.SuspendLayout();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges1;
            // 
            // guna2Panel3
            // 
            guna2Panel3.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Panel3.Size = new Size(1980, 44);
            // 
            // guna2Panel4
            // 
            guna2Panel4.ShadowDecoration.CustomizableEdges = customizableEdges3;
            // 
            // guna2Panel5
            // 
            guna2Panel5.ShadowDecoration.CustomizableEdges = customizableEdges4;
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.Controls.Add(guna2Panel6);
            guna2CustomGradientPanel1.Controls.Add(lblCustomerName);
            guna2CustomGradientPanel1.Controls.Add(guna2Button6);
            guna2CustomGradientPanel1.Controls.Add(btnDeposits);
            guna2CustomGradientPanel1.Controls.Add(btnDocument);
            guna2CustomGradientPanel1.Controls.Add(btnNote);
            guna2CustomGradientPanel1.Controls.Add(btnBooking);
            guna2CustomGradientPanel1.Controls.Add(btnSummary);
            guna2CustomGradientPanel1.Controls.Add(guna2Panel2);
            guna2CustomGradientPanel1.Controls.Add(CustomerImage);
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges22;
            guna2CustomGradientPanel1.Size = new Size(1252, 677);
            guna2CustomGradientPanel1.Paint += guna2CustomGradientPanel1_Paint;
            // 
            // CustomerImage
            // 
            CustomerImage.BackColor = Color.FromArgb(23, 89, 119);
            CustomerImage.ImageRotate = 0F;
            CustomerImage.Location = new Point(144, 52);
            CustomerImage.Name = "CustomerImage";
            CustomerImage.ShadowDecoration.CustomizableEdges = customizableEdges21;
            CustomerImage.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            CustomerImage.Size = new Size(103, 101);
            CustomerImage.TabIndex = 0;
            CustomerImage.TabStop = false;
            // 
            // guna2Panel2
            // 
            guna2Panel2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            guna2Panel2.Controls.Add(lblcustomerAddress);
            guna2Panel2.Controls.Add(lblCustomerEmail);
            guna2Panel2.Controls.Add(txtCustomerPhone);
            guna2Panel2.Controls.Add(lblEmail);
            guna2Panel2.Controls.Add(guna2vSeparator2);
            guna2Panel2.Controls.Add(lblAddress);
            guna2Panel2.Controls.Add(guna2vSeparator1);
            guna2Panel2.Controls.Add(lblCustomerPhone);
            guna2Panel2.CustomizableEdges = customizableEdges19;
            guna2Panel2.Location = new Point(100, 196);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2Panel2.Size = new Size(988, 154);
            guna2Panel2.TabIndex = 1;
            // 
            // lblcustomerAddress
            // 
            lblcustomerAddress.AutoSize = true;
            lblcustomerAddress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblcustomerAddress.ForeColor = Color.White;
            lblcustomerAddress.Location = new Point(620, 73);
            lblcustomerAddress.Name = "lblcustomerAddress";
            lblcustomerAddress.RightToLeft = RightToLeft.No;
            lblcustomerAddress.Size = new Size(0, 21);
            lblcustomerAddress.TabIndex = 11;
            // 
            // lblCustomerEmail
            // 
            lblCustomerEmail.AutoSize = true;
            lblCustomerEmail.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblCustomerEmail.ForeColor = Color.White;
            lblCustomerEmail.Location = new Point(254, 73);
            lblCustomerEmail.Name = "lblCustomerEmail";
            lblCustomerEmail.RightToLeft = RightToLeft.No;
            lblCustomerEmail.Size = new Size(0, 21);
            lblCustomerEmail.TabIndex = 10;
            // 
            // txtCustomerPhone
            // 
            txtCustomerPhone.AutoSize = true;
            txtCustomerPhone.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtCustomerPhone.ForeColor = Color.White;
            txtCustomerPhone.Location = new Point(26, 73);
            txtCustomerPhone.Name = "txtCustomerPhone";
            txtCustomerPhone.RightToLeft = RightToLeft.No;
            txtCustomerPhone.Size = new Size(0, 21);
            txtCustomerPhone.TabIndex = 6;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            lblEmail.ForeColor = Color.White;
            lblEmail.Location = new Point(254, 17);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(58, 25);
            lblEmail.TabIndex = 5;
            lblEmail.Text = "Email";
            lblEmail.Click += label2_Click;
            // 
            // guna2vSeparator2
            // 
            guna2vSeparator2.Location = new Point(596, 12);
            guna2vSeparator2.Name = "guna2vSeparator2";
            guna2vSeparator2.Size = new Size(10, 131);
            guna2vSeparator2.TabIndex = 4;
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            lblAddress.ForeColor = Color.White;
            lblAddress.Location = new Point(620, 17);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(79, 25);
            lblAddress.TabIndex = 3;
            lblAddress.Text = "Address";
            // 
            // guna2vSeparator1
            // 
            guna2vSeparator1.Location = new Point(233, 13);
            guna2vSeparator1.Name = "guna2vSeparator1";
            guna2vSeparator1.Size = new Size(10, 131);
            guna2vSeparator1.TabIndex = 2;
            // 
            // lblCustomerPhone
            // 
            lblCustomerPhone.AutoSize = true;
            lblCustomerPhone.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            lblCustomerPhone.ForeColor = Color.White;
            lblCustomerPhone.Location = new Point(26, 17);
            lblCustomerPhone.Name = "lblCustomerPhone";
            lblCustomerPhone.Size = new Size(140, 25);
            lblCustomerPhone.TabIndex = 0;
            lblCustomerPhone.Text = "Phone Number";
            lblCustomerPhone.Click += lblCustomerPhone_Click;
            // 
            // btnSummary
            // 
            btnSummary.Anchor = AnchorStyles.Left;
            btnSummary.AutoRoundedCorners = true;
            btnSummary.BackColor = Color.FromArgb(23, 89, 119);
            btnSummary.BorderRadius = 21;
            customizableEdges17.BottomRight = false;
            customizableEdges17.TopRight = false;
            btnSummary.CustomizableEdges = customizableEdges17;
            btnSummary.DisabledState.BorderColor = Color.DarkGray;
            btnSummary.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSummary.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSummary.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSummary.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSummary.ForeColor = Color.White;
            btnSummary.Location = new Point(126, 387);
            btnSummary.Name = "btnSummary";
            btnSummary.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnSummary.Size = new Size(180, 45);
            btnSummary.TabIndex = 2;
            btnSummary.Text = "Summary";
            // 
            // btnBooking
            // 
            btnBooking.Anchor = AnchorStyles.Left;
            btnBooking.CustomizableEdges = customizableEdges15;
            btnBooking.DisabledState.BorderColor = Color.DarkGray;
            btnBooking.DisabledState.CustomBorderColor = Color.DarkGray;
            btnBooking.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnBooking.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnBooking.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnBooking.ForeColor = Color.White;
            btnBooking.Location = new Point(314, 387);
            btnBooking.Name = "btnBooking";
            btnBooking.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnBooking.Size = new Size(180, 45);
            btnBooking.TabIndex = 3;
            btnBooking.Text = "Booking";
            btnBooking.Click += btnBooking_Click;
            // 
            // btnNote
            // 
            btnNote.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            btnNote.CustomizableEdges = customizableEdges13;
            btnNote.DisabledState.BorderColor = Color.DarkGray;
            btnNote.DisabledState.CustomBorderColor = Color.DarkGray;
            btnNote.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnNote.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnNote.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnNote.ForeColor = Color.White;
            btnNote.Location = new Point(502, 387);
            btnNote.Name = "btnNote";
            btnNote.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnNote.Size = new Size(180, 45);
            btnNote.TabIndex = 4;
            btnNote.Text = "Notes";
            // 
            // btnDocument
            // 
            btnDocument.Anchor = AnchorStyles.Right;
            btnDocument.CustomizableEdges = customizableEdges11;
            btnDocument.DisabledState.BorderColor = Color.DarkGray;
            btnDocument.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDocument.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDocument.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDocument.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnDocument.ForeColor = Color.White;
            btnDocument.Location = new Point(690, 387);
            btnDocument.Name = "btnDocument";
            btnDocument.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnDocument.Size = new Size(180, 44);
            btnDocument.TabIndex = 5;
            btnDocument.Text = "Documents";
            btnDocument.Click += btnDocument_Click;
            // 
            // btnDeposits
            // 
            btnDeposits.Anchor = AnchorStyles.Right;
            btnDeposits.AutoRoundedCorners = true;
            btnDeposits.BackColor = Color.FromArgb(23, 89, 119);
            btnDeposits.BorderRadius = 21;
            customizableEdges9.BottomLeft = false;
            customizableEdges9.TopLeft = false;
            btnDeposits.CustomizableEdges = customizableEdges9;
            btnDeposits.DisabledState.BorderColor = Color.DarkGray;
            btnDeposits.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDeposits.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDeposits.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDeposits.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnDeposits.ForeColor = Color.White;
            btnDeposits.Location = new Point(878, 387);
            btnDeposits.Name = "btnDeposits";
            btnDeposits.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnDeposits.Size = new Size(180, 45);
            btnDeposits.TabIndex = 6;
            btnDeposits.Text = "Deposits";
            // 
            // guna2Button6
            // 
            guna2Button6.AutoRoundedCorners = true;
            guna2Button6.BackColor = Color.FromArgb(23, 89, 119);
            guna2Button6.BorderRadius = 34;
            guna2Button6.CustomizableEdges = customizableEdges7;
            guna2Button6.DisabledState.BorderColor = Color.DarkGray;
            guna2Button6.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button6.FillColor = Color.Transparent;
            guna2Button6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button6.ForeColor = Color.White;
            guna2Button6.Image = (Image)resources.GetObject("guna2Button6.Image");
            guna2Button6.ImageSize = new Size(70, 70);
            guna2Button6.Location = new Point(15, 67);
            guna2Button6.Name = "guna2Button6";
            guna2Button6.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2Button6.Size = new Size(80, 71);
            guna2Button6.TabIndex = 7;
            guna2Button6.Click += guna2Button6_Click;
            // 
            // lblCustomerName
            // 
            lblCustomerName.AutoSize = true;
            lblCustomerName.BackColor = Color.Transparent;
            lblCustomerName.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblCustomerName.ForeColor = Color.White;
            lblCustomerName.Location = new Point(268, 93);
            lblCustomerName.Name = "lblCustomerName";
            lblCustomerName.Size = new Size(0, 25);
            lblCustomerName.TabIndex = 8;
            // 
            // guna2Panel6
            // 
            guna2Panel6.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            guna2Panel6.BackColor = Color.FromArgb(23, 89, 119);
            guna2Panel6.CustomizableEdges = customizableEdges5;
            guna2Panel6.Location = new Point(165, 465);
            guna2Panel6.Name = "guna2Panel6";
            guna2Panel6.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Panel6.Size = new Size(904, 184);
            guna2Panel6.TabIndex = 9;
            // 
            // UserDetail
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1390, 757);
            Name = "UserDetail";
            Text = "UserDetail";
            guna2CustomGradientPanel1.ResumeLayout(false);
            guna2CustomGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)CustomerImage).EndInit();
            guna2Panel2.ResumeLayout(false);
            guna2Panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2CirclePictureBox CustomerImage;
        private Guna.UI2.WinForms.Guna2Button btnDeposits;
        private Guna.UI2.WinForms.Guna2Button btnDocument;
        private Guna.UI2.WinForms.Guna2Button btnNote;
        private Guna.UI2.WinForms.Guna2Button btnBooking;
        private Guna.UI2.WinForms.Guna2Button btnSummary;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Label lblCustomerName;
        private Label lblCustomerPhone;
        private Label lblEmail;
        private Guna.UI2.WinForms.Guna2VSeparator guna2vSeparator2;
        private Label lblAddress;
        private Guna.UI2.WinForms.Guna2VSeparator guna2vSeparator1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Label txtCustomerPhone;
        private Label lblcustomerAddress;
        private Label lblCustomerEmail;
    }
}