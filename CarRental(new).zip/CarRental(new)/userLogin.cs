﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental
{
    public partial class userLogin : Form
    {
        public userLogin()
        {
            InitializeComponent();
        }

        private void btnSup_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm frm = new LoginForm();
            frm.Show();
        }


        private void btnLogin_Click(object sender, EventArgs e)
        {
            int customerID = MainClass.GetCustomerID(textBoxUser.Text, textBoxPass.Text);
            if (MainClass.IsValidCustomer(textBoxUser.Text, textBoxPass.Text) == false)
            {

                guna2MessageDialog1.Show("Wrong Login info. Try Again.");
                return;
            }
            else
            {

                this.Hide();
                MainFormforUser frm = new MainFormforUser(customerID);
                frm.Show();
            }
        }

    }
}
