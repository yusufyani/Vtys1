using Guna.UI2.WinForms;

namespace CarRental
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LoginForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin.PerformClick();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (MainClass.IsValidUser(textBoxUser.Text, textBoxPass.Text) == false)
            {

                guna2MessageDialog1.Show("Wrong Login info. Try Again.");
                return;
            }
            else
            {

                this.Hide();
                MainForm frm = new MainForm();
                frm.Show();
            }

        }

        private void btnSup_Click(object sender, EventArgs e)
        {
            this.Hide();
            userLogin frm = new userLogin();
            frm.Show();
        }
    }
}