﻿using CarRental.UserForms;
using CarRental.Details.UserForms;
using CarRental.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental
{
    public partial class MainFormforUser : Sample
    {
        private int customerID;
        public MainFormforUser(int customerID)
        {
            InitializeComponent();
            this.customerID = customerID;

        }


        private Form currentForm = null;
        public void AddControlls(Form f)
        {
            guna2Panel2.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            guna2Panel2.Controls.Add(f);
            f.Show();
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            if (currentForm == null || currentForm.GetType() != typeof(UserView))
            {
                currentForm = new UserView(customerID);
                AddControlls(currentForm);
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (currentForm == null || currentForm.GetType() != typeof(Vehicles))
            {
                currentForm = new Vehicles();
                AddControlls(currentForm);
            }
        }

        private void guna2Button10_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
                this.StartPosition = FormStartPosition.CenterScreen;
            }
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
