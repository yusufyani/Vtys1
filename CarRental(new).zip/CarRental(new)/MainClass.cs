﻿using Guna.UI2.WinForms;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CarRental
{
    internal class MainClass
    {
        public static readonly string con_string = "Data Source=YUSUF; Initial Catalog=CarRental;Persist Security Info=True;User ID=sa;Password=123;";
        public static readonly SqlConnection con = new SqlConnection(con_string);

        public static bool IsValidUser(string user, string pass)
        {
            bool isValid = false;
            string query = "SELECT COUNT(*) FROM Users WHERE uUser = @user AND uPass = @pass";

            using (SqlConnection con = new SqlConnection(con_string)) // Bağlantı dizesini doğru şekilde belirtmelisiniz.
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@user", user);
                    cmd.Parameters.AddWithValue("@pass", pass);

                    int count = (int)cmd.ExecuteScalar();
                    isValid = count > 0;
                }

                if (isValid)
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT uName FROM Users WHERE uUser = @user", con))
                    {
                        cmd.Parameters.AddWithValue("@user", user);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                USER = reader["uName"].ToString();
                            }
                        }
                    }
                }
            }

            return isValid;
        }

        public static bool IsValidCustomer(string user, string pass)
        {
            bool isValid = false;
            string query = "SELECT COUNT(*) FROM Customers WHERE cUsername = @user AND cPass = @pass";

            using (SqlConnection con = new SqlConnection(con_string)) 
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@user", user);
                    cmd.Parameters.AddWithValue("@pass", pass);

                    int count = (int)cmd.ExecuteScalar();
                    isValid = count > 0;
                }

                if (isValid)
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT cFirstName FROM Customers WHERE cUsername = @user", con))
                    {
                        cmd.Parameters.AddWithValue("@user", user);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                USER = reader["cFirstName"].ToString();
                            }
                        }
                    }
                }
            }

            return isValid;
        }

        static string user;
        public static string USER
        {
            get { return user; }
            set { user = value; }
        }

        public static int GetCustomerID(string user, string pass)
        {
            int customerID = -1; // Varsayılan olarak geçersiz bir değer

            string query = "SELECT CustomerID FROM Customers WHERE cUsername = @user AND cPass = @pass";

            using (SqlConnection con = new SqlConnection(con_string))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@user", user);
                    cmd.Parameters.AddWithValue("@pass", pass);

                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        customerID = (int)result;
                    }
                }
            }

            return customerID;
        }
        public static int SQl(string qry, Hashtable ht)
        {
            int res = 0;

            try
            {
                using (SqlConnection con = new SqlConnection(con_string))
                using (SqlCommand cmd = new SqlCommand(qry, con))
                {
                    cmd.CommandType = CommandType.Text;

                    foreach (DictionaryEntry item in ht)
                    {
                        cmd.Parameters.AddWithValue(item.Key.ToString(), item.Value);
                    }

                    con.Open();

                    res = cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Veritabanı işlemi sırasında bir hata oluştu: " + ex.Message);
            }
            return res;
        }


        public static void LoadData(string qry, DataGridView gv, ListBox lb)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                for (int i = 0; i < lb.Items.Count; i++)
                {
                    string colNam1 = ((DataGridViewColumn)lb.Items[i]).Name;
                    gv.Columns[colNam1].DataPropertyName = dt.Columns[i].ToString();
                }
                gv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                con.Close();
            }


        }


        public static void CBFill(string qry, ComboBox cb)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cb.DisplayMember = "name";
                cb.ValueMember = "id";

                cb.DataSource = dt;
            }
            catch (Exception ex)
            {
                MainClass.con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        public static void SrNo(Guna.UI2.WinForms.Guna2DataGridView gv, ref int srValue)
        {
            try
            {
                foreach (DataGridViewRow row in gv.Rows)
                {
                    srValue++;
                    row.Cells["dgvSr"].Value = srValue;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
        }

        private static Color vColor = Color.FromArgb(245, 29, 70);

        public static bool Validation(Form F)
        {
            Label lbl = new Label();
            bool isvalid = true;
            int count = 0;
            int x;
            int y;

            var dynamiclabels = F.Controls.OfType<Label>().Where(c => c.Tag != null && c.Tag.ToString() == "remove").ToList();
            foreach (var lbl1 in dynamiclabels)
            {
                F.Controls.Remove(lbl1);
            }
            foreach (Control c in F.Controls)
            {
                if (c is Guna.UI2.WinForms.Guna2Button)
                {

                }
                else
                {
                    if (c.Tag == null || c.Tag.ToString() == string.Empty)
                    {

                    }
                    else
                    {

                        if (c is Guna.UI2.WinForms.Guna2TextBox)
                        {
                            Guna.UI2.WinForms.Guna2TextBox t = (Guna.UI2.WinForms.Guna2TextBox)c;
                            if (t.AutoRoundedCorners == true)
                            {
                                x = int.Parse(c.Location.X.ToString()) + 10;
                                y = int.Parse(c.Location.Y.ToString()) + 5 + int.Parse(c.Height.ToString());
                            }
                            else
                            {
                                x = int.Parse(c.Location.X.ToString());
                                y = int.Parse(c.Location.Y.ToString()) + 5 + int.Parse(c.Height.ToString());
                            }
                            if (t.Text == "")
                            {
                                string cname = "vlbl" + c.Name;
                                lbl.Name = cname;
                                lbl.Tag = "remove";
                                lbl.Text = "Required";
                                lbl.ForeColor = vColor;
                                F.Controls.Add(lbl);

                                lbl.Location = new System.Drawing.Point(x, y);

                                count++;
                            }
                        }



                    }
                }
            }

            if (count == 0)
            {
                isvalid = true;
            }
            else
            {
                isvalid = false;
            }

            return isvalid;
        }
        public static void Enable_reset(Form p)
        {
            foreach (Control c in p.Controls)
            {
                if (c is Guna.UI2.WinForms.Guna2TextBox)
                {
                    Guna.UI2.WinForms.Guna2TextBox t = (Guna.UI2.WinForms.Guna2TextBox)c;

                    t.Text = "";
                }

                if (c is Guna.UI2.WinForms.Guna2ComboBox)
                {
                    Guna.UI2.WinForms.Guna2ComboBox cb = (Guna.UI2.WinForms.Guna2ComboBox)c;

                    cb.SelectedIndex = 0;
                    cb.SelectedIndex = -1;
                }

                if (c is Guna.UI2.WinForms.Guna2RadioButton)
                {
                    Guna.UI2.WinForms.Guna2RadioButton rb = (Guna.UI2.WinForms.Guna2RadioButton)c;
                    rb.Checked = false;
                }

                if (c is Guna.UI2.WinForms.Guna2CheckBox)
                {
                    Guna.UI2.WinForms.Guna2CheckBox ck = (Guna.UI2.WinForms.Guna2CheckBox)c;
                    ck.Checked = false;
                }

                if (c is ListBox)
                {
                    ListBox list = (ListBox)c;
                }

                if (c is NumericUpDown)
                {
                    NumericUpDown cb = (NumericUpDown)c;
                    cb.Value = 0;
                }

                if (c is MaskedTextBox)
                {
                    MaskedTextBox cb = (MaskedTextBox)c;
                    cb.Text = "";
                }

            }
        }

        internal static void CBFill(string qry, object cbCat)
        {
            throw new NotImplementedException();
        }

        public static decimal CalculateNetAmount(string qry, DateTime dt1, DateTime dt2, Hashtable prm)
        {
            decimal netAmount = 0; // netAmount'u decimal olarak tanımlayın

            using (con)
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(qry, con))
                {
                    int vehicleID = (int)prm["@Vehicle"];

                    cmd.Parameters.AddWithValue("@Vehicle", vehicleID);

                    decimal dailyRentalRate = Convert.ToDecimal(cmd.ExecuteScalar());

                    TimeSpan span = dt2 - dt1;
                    int rentalDays = span.Days;

                    netAmount = dailyRentalRate * rentalDays;




                }
            }
            return netAmount;
        }
        public static T ExecuteScalar<T>(string qry, Hashtable ht)
        {
            T result = default(T);

            try
            {
                using (SqlConnection con = new SqlConnection(con_string))
                using (SqlCommand cmd = new SqlCommand(qry, con))
                {
                    con.Open();

                    // Parametreleri ekleyin
                    foreach (DictionaryEntry item in ht)
                    {
                        cmd.Parameters.AddWithValue(item.Key.ToString(), item.Value);
                    }

                    // Sorguyu çalıştırın ve sonucu alın
                    object scalarResult = cmd.ExecuteScalar();

                    if (scalarResult != null && scalarResult != DBNull.Value)
                    {
                        result = (T)Convert.ChangeType(scalarResult, typeof(T));
                    }

                    con.Close();
                }
            }
            catch (Exception ex)
            {
                // Hata yönetimi burada gerçekleştirilebilir
            }

            return result;
        }
    }
}


