﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarRental.Addes;
using CarRental.Models;
using Guna.Charts.WinForms;

namespace CarRental
{
    public partial class MainForm : Sample
    {
        public MainForm()
        {
            InitializeComponent();
        }
        private Form currentForm = null;
        public void AddControlls(Form f)
        {
            guna2Panel2.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            guna2Panel2.Controls.Add(f);
            f.Show();
        }




        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
                this.StartPosition = FormStartPosition.CenterScreen;
            }
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (currentForm == null || currentForm.GetType() != typeof(Bookings))
            {
                currentForm = new Bookings();
                AddControlls(currentForm);
            }
        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            if (currentForm == null || currentForm.GetType() != typeof(History))
            {
                currentForm = new History();
                AddControlls(currentForm);
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            if (currentForm == null || currentForm.GetType() != typeof(Dashboard))
            {
                currentForm = new Dashboard();
                AddControlls(currentForm);
            }
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            if (currentForm == null || currentForm.GetType() != typeof(Customers))
            {
                currentForm = new Customers();
                AddControlls(currentForm);
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (currentForm == null || currentForm.GetType() != typeof(CarList))
            {
                currentForm = new CarList();
                AddControlls(currentForm);
            }
        }

        internal void UpdateDataGridView(List<AddDocument.Document> documents)
        {
            throw new NotImplementedException();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            lblUser.Text = MainClass.USER;
        }
    }
}
