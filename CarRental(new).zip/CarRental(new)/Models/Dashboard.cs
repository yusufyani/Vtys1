﻿using Guna.Charts.WinForms;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Models
{
    public partial class Dashboard : SampleModel
    {
        public Dashboard()
        {
            InitializeComponent();
            InitializeGunaChart();
        }
        private GunaSplineAreaDataset gunaSplineAreaDataset;
        private GunaDoughnutDataset gunaDoughnutDataset;
        private void InitializeGunaChart()
        {
            // for SplineArea
            gunaSplineAreaDataset = new GunaSplineAreaDataset();
            gunaSplineAreaDataset.BorderColor = Color.DeepPink;
            gunaSplineAreaDataset.BorderWidth = 3;
            gunaSplineAreaDataset.Label = "Revenue";
            gunaSplineAreaDataset.YFormat = "Available {0:A}";

            // for Doughnut
            gunaDoughnutDataset = new GunaDoughnutDataset();
            // gunaDoughnutDataset.BorderColors = Color.Azure;
            gunaDoughnutDataset.BorderWidth = 5;
            gunaDoughnutDataset.Label = "Available Cars";
            gunaDoughnutDataset.YFormat = "{0:A}";

            gunaChart2.Datasets.Add(gunaSplineAreaDataset);
            gunaChart1.Datasets.Add(gunaDoughnutDataset);

            GenerateDataAndLabels();

        }
        private void GenerateDataAndLabels()
        {
            string[] Type = { "Sedan", "Hatchback", "SUV" }; ;
            string[] monthLabels = { "January", "February", "March", "April", "May", "June", "July" };


            var random1 = new Random();
            foreach (var label1 in monthLabels)
            {
                gunaSplineAreaDataset.DataPoints.Add(new LPoint()
                {
                    Label = label1,
                    Y = random1.Next(10, 100),
                });
            }
            var random2 = new Random();
            foreach (var label in Type)
            {
                gunaSplineAreaDataset.DataPoints.Add(new LPoint()
                {
                    Label = label,
                    Y = random1.Next(10, 100),
                });
            }

        }


        public void Dashboard_Load(object sender, EventArgs e)
        {
            GetData();
        }
        private void GetData()
        {
            string qry = "SELECT COUNT(*) FROM Vehicles WHERE Availability = 1"; // 1 olanlar "true" durumundaki araçları temsil ediyor
            int availableCount = 0;

            using (SqlConnection con = new SqlConnection("Data Source=YUSUF; Initial Catalog=CarRental;Persist Security Info=True;User ID=sa;Password=123;"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(qry, con);
                availableCount = (int)cmd.ExecuteScalar();
            }

            lblAvailable.Text = availableCount.ToString();
        }

        private void GetReservationCount()
        {
            string qry = "SELECT COUNT(*) FROM Reservations";

            using (SqlConnection con = new SqlConnection("Data Source=YUSUF; Initial Catalog=CarRental;Persist Security Info=True;User ID=sa;Password=123;"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(qry, con);
                int reservationCount = (int)cmd.ExecuteScalar();
                lblBooking.Text = reservationCount.ToString();
            }
        }

        private void GetCarsOnRentCount()
        {
            // İçinde bulunduğumuz tarih
            DateTime today = DateTime.Now.Date;

            string qry = $"SELECT COUNT(*) FROM Reservations WHERE @Today BETWEEN RentalStartDate AND RentalEndDate";

            using (SqlConnection con = new SqlConnection("Data Source=YUSUF; Initial Catalog=CarRental;Persist Security Info=True;User ID=sa;Password=123;"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.Parameters.AddWithValue("@Today", today);
                int onRentCount = (int)cmd.ExecuteScalar();
                lblOnRent.Text = onRentCount.ToString();
            }
        }


        private void gunaChart2_Load(object sender, EventArgs e)
        {

        }

        private void guna2Panel6_Paint(object sender, PaintEventArgs e)
        {
            GetData();
        }

        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Panel2_Paint(object sender, PaintEventArgs e)
        {
            GetReservationCount();
        }

        private void guna2Panel7_Paint(object sender, PaintEventArgs e)
        {
            GetCarsOnRentCount();
        }
    }
}


