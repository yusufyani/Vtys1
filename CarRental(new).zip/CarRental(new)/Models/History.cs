﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Models
{
    public partial class History : SampleModel
    {
        public History()
        {
            InitializeComponent();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            string qry = "SELECT r.RentalID,r.ReservationDate, r.RentalStartDate, r.RentalEndDate, r.CustomerID, r.VehicleID, v.BrandModel, r.TotalRentalFee FROM RentalHistory r INNER JOIN Vehicles v ON v.VehicleID = r.VehicleID WHERE r.ReservationDate LIKE '%" + txtSearch.Text + "%'";
            ListBox lb = new ListBox();
            lb.Items.Add(dgvid);
            lb.Items.Add(dgvReservation);
            lb.Items.Add(dgvDoS);
            lb.Items.Add(dgvDoE);
            lb.Items.Add(dgvCustomer);
            lb.Items.Add(dgvVid);
            lb.Items.Add(BrandModel);
            lb.Items.Add(DgvNet);
            MainClass.LoadData(qry, guna2DataGridView1, lb);

        }

        public void MoveReservationsToHistory()
        {
            using (SqlConnection con = new SqlConnection("Data Source=YUSUF; Initial Catalog=CarRental;Persist Security Info=True;User ID=sa;Password=123;"))
            {
                con.Open();

                // 1. RentalEndDay'den sonraki rezervasyonları seçin
                string selectQuery = "SELECT * FROM Reservations WHERE RentalEndDate <= GETDATE()";
                SqlDataAdapter adapter = new SqlDataAdapter(selectQuery, con);
                DataTable reservationsToMove = new DataTable();
                adapter.Fill(reservationsToMove);

                // 2. RentalEndDay'den sonraki rezervasyonları Reservations tablosundan silin
                string deleteQuery = "DELETE FROM Reservations WHERE RentalEndDate <= GETDATE()";
                SqlCommand deleteCommand = new SqlCommand(deleteQuery, con);
                deleteCommand.ExecuteNonQuery();

                // 3. Geçici tablodaki rezervasyonları RentalHistory tablosuna ekleyin
                foreach (DataRow row in reservationsToMove.Rows)
                {
                    string insertQuery = "INSERT INTO RentalHistory (ReservationDate, RentalStartDate, RentalEndDate, CustomerID, VehicleID, TotalRentalFee) " +
                        "VALUES (@ReservationDate, @RentalStartDay, @RentalEndDay, @CustomerID, @VehicleID, @TotalRentalFee)";
                    SqlCommand insertCommand = new SqlCommand(insertQuery, con);
                    insertCommand.Parameters.AddWithValue("@ReservationDate", row["ReservationDate"]);
                    insertCommand.Parameters.AddWithValue("@RentalStartDay", row["RentalStartDate"]);
                    insertCommand.Parameters.AddWithValue("@RentalEndDay", row["RentalEndDate"]);
                    insertCommand.Parameters.AddWithValue("@CustomerID", row["CustomerID"]);
                    insertCommand.Parameters.AddWithValue("@VehicleID", row["VehicleID"]);
                    insertCommand.Parameters.AddWithValue("@TotalRentalFee", row["NetAmount"]);
                    insertCommand.ExecuteNonQuery();
                }
            }
        }

        private void History_Load(object sender, EventArgs e)
        {
            MoveReservationsToHistory();
            LoadData();
        }
    }
}
