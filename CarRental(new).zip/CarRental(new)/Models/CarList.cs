﻿using CarRental.Addes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Models
{
    public partial class CarList : SampleModel
    {
        public CarList()
        {
            InitializeComponent();
        }

        private void CarList_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        int srValue = 0;
        private void LoadData()
        {
            string qry = "SELECT * FROM Vehicles WHERE BrandModel LIKE '%" + txtSearch.Text + "%'";
            ListBox lb = new ListBox();
            lb.Items.Add(dgvid);
            lb.Items.Add(dgvBrand);
            lb.Items.Add(dgvPlate);
            lb.Items.Add(dgvYear);
            lb.Items.Add(dgvFuel);
            lb.Items.Add(dgvDailyRental);
            lb.Items.Add(dgvDesc);
            lb.Items.Add(dgvAvailable);
            lb.Items.Add(dgvCat);
            lb.Items.Add(dgvimg);
            lb.Items.Add(dgveimage1);
            lb.Items.Add(dgveimage2);
            lb.Items.Add(dgveimage3);
            MainClass.LoadData(qry, guna2DataGridView1, lb);

        }

        private Image ByteArrayToImage(byte[] byteArrayIn)
        {
            using (MemoryStream ms = new MemoryStream(byteArrayIn))
            {
                Image image = Image.FromStream(ms);
                return image;
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            new AddCar().Show();
        }
    }
}
