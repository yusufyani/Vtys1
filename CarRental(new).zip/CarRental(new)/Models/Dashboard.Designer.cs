﻿namespace CarRental.Models
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.Charts.WinForms.ChartFont chartFont9 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.ChartFont chartFont10 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.ChartFont chartFont11 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.ChartFont chartFont12 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.Grid grid4 = new Guna.Charts.WinForms.Grid();
            Guna.Charts.WinForms.Tick tick4 = new Guna.Charts.WinForms.Tick();
            Guna.Charts.WinForms.ChartFont chartFont13 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.Grid grid5 = new Guna.Charts.WinForms.Grid();
            Guna.Charts.WinForms.Tick tick5 = new Guna.Charts.WinForms.Tick();
            Guna.Charts.WinForms.ChartFont chartFont14 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.Grid grid6 = new Guna.Charts.WinForms.Grid();
            Guna.Charts.WinForms.PointLabel pointLabel2 = new Guna.Charts.WinForms.PointLabel();
            Guna.Charts.WinForms.ChartFont chartFont15 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.Tick tick6 = new Guna.Charts.WinForms.Tick();
            Guna.Charts.WinForms.ChartFont chartFont16 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.ChartFont chartFont1 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.ChartFont chartFont2 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.ChartFont chartFont3 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.ChartFont chartFont4 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.Grid grid1 = new Guna.Charts.WinForms.Grid();
            Guna.Charts.WinForms.Tick tick1 = new Guna.Charts.WinForms.Tick();
            Guna.Charts.WinForms.ChartFont chartFont5 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.Grid grid2 = new Guna.Charts.WinForms.Grid();
            Guna.Charts.WinForms.Tick tick2 = new Guna.Charts.WinForms.Tick();
            Guna.Charts.WinForms.ChartFont chartFont6 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.Grid grid3 = new Guna.Charts.WinForms.Grid();
            Guna.Charts.WinForms.PointLabel pointLabel1 = new Guna.Charts.WinForms.PointLabel();
            Guna.Charts.WinForms.ChartFont chartFont7 = new Guna.Charts.WinForms.ChartFont();
            Guna.Charts.WinForms.Tick tick3 = new Guna.Charts.WinForms.Tick();
            Guna.Charts.WinForms.ChartFont chartFont8 = new Guna.Charts.WinForms.ChartFont();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            lblBooking = new Label();
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            label1 = new Label();
            guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            lblAvailable = new Label();
            guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            label2 = new Label();
            guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            lblOnRent = new Label();
            guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            label3 = new Label();
            guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            label4 = new Label();
            label5 = new Label();
            gunaAreaDataset1 = new Guna.Charts.WinForms.GunaAreaDataset();
            label6 = new Label();
            label7 = new Label();
            gunaChart1 = new Guna.Charts.WinForms.GunaChart();
            gunaChart2 = new Guna.Charts.WinForms.GunaChart();
            guna2Panel3.SuspendLayout();
            guna2CustomGradientPanel1.SuspendLayout();
            guna2Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            guna2Panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox2).BeginInit();
            guna2Panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox3).BeginInit();
            guna2Panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox4).BeginInit();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges1;
            // 
            // guna2Panel3
            // 
            guna2Panel3.Controls.Add(label5);
            guna2Panel3.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Panel3.Size = new Size(1393, 44);
            // 
            // guna2Panel4
            // 
            guna2Panel4.ShadowDecoration.CustomizableEdges = customizableEdges3;
            // 
            // guna2Panel5
            // 
            guna2Panel5.ShadowDecoration.CustomizableEdges = customizableEdges4;
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.AutoScroll = true;
            guna2CustomGradientPanel1.Controls.Add(gunaChart2);
            guna2CustomGradientPanel1.Controls.Add(gunaChart1);
            guna2CustomGradientPanel1.Controls.Add(label7);
            guna2CustomGradientPanel1.Controls.Add(label6);
            guna2CustomGradientPanel1.Controls.Add(guna2Panel8);
            guna2CustomGradientPanel1.Controls.Add(guna2Panel7);
            guna2CustomGradientPanel1.Controls.Add(guna2Panel6);
            guna2CustomGradientPanel1.Controls.Add(guna2Panel2);
            guna2CustomGradientPanel1.Quality = 40;
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges21;
            guna2CustomGradientPanel1.Size = new Size(1257, 677);
            guna2CustomGradientPanel1.Paint += guna2CustomGradientPanel1_Paint;
            // 
            // guna2Panel2
            // 
            guna2Panel2.AutoRoundedCorners = true;
            guna2Panel2.BackColor = Color.Transparent;
            guna2Panel2.BorderRadius = 48;
            guna2Panel2.Controls.Add(lblBooking);
            guna2Panel2.Controls.Add(guna2PictureBox1);
            guna2Panel2.Controls.Add(label1);
            guna2Panel2.CustomizableEdges = customizableEdges19;
            guna2Panel2.FillColor = Color.FromArgb(176, 132, 240);
            guna2Panel2.Location = new Point(159, 119);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2Panel2.Size = new Size(200, 99);
            guna2Panel2.TabIndex = 0;
            guna2Panel2.Paint += guna2Panel2_Paint;
            // 
            // lblBooking
            // 
            lblBooking.AutoSize = true;
            lblBooking.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblBooking.Location = new Point(95, 19);
            lblBooking.Name = "lblBooking";
            lblBooking.Size = new Size(0, 40);
            lblBooking.TabIndex = 4;
            // 
            // guna2PictureBox1
            // 
            guna2PictureBox1.CustomizableEdges = customizableEdges17;
            guna2PictureBox1.Image = Properties.Resources.booking__1_;
            guna2PictureBox1.ImageRotate = 0F;
            guna2PictureBox1.Location = new Point(15, 34);
            guna2PictureBox1.Name = "guna2PictureBox1";
            guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2PictureBox1.Size = new Size(44, 39);
            guna2PictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox1.TabIndex = 2;
            guna2PictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(75, 65);
            label1.Name = "label1";
            label1.Size = new Size(74, 21);
            label1.TabIndex = 1;
            label1.Text = "Bookings";
            // 
            // guna2Panel6
            // 
            guna2Panel6.AutoRoundedCorners = true;
            guna2Panel6.BackColor = Color.Transparent;
            guna2Panel6.BorderRadius = 48;
            guna2Panel6.Controls.Add(lblAvailable);
            guna2Panel6.Controls.Add(guna2PictureBox2);
            guna2Panel6.Controls.Add(label2);
            guna2Panel6.CustomizableEdges = customizableEdges15;
            guna2Panel6.FillColor = Color.Pink;
            guna2Panel6.Location = new Point(414, 119);
            guna2Panel6.Name = "guna2Panel6";
            guna2Panel6.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2Panel6.Size = new Size(200, 99);
            guna2Panel6.TabIndex = 1;
            guna2Panel6.Paint += guna2Panel6_Paint;
            // 
            // lblAvailable
            // 
            lblAvailable.AutoSize = true;
            lblAvailable.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblAvailable.Location = new Point(99, 19);
            lblAvailable.Name = "lblAvailable";
            lblAvailable.Size = new Size(0, 40);
            lblAvailable.TabIndex = 3;
            // 
            // guna2PictureBox2
            // 
            guna2PictureBox2.CustomizableEdges = customizableEdges13;
            guna2PictureBox2.Image = (Image)resources.GetObject("guna2PictureBox2.Image");
            guna2PictureBox2.ImageRotate = 0F;
            guna2PictureBox2.Location = new Point(15, 34);
            guna2PictureBox2.Name = "guna2PictureBox2";
            guna2PictureBox2.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2PictureBox2.Size = new Size(44, 39);
            guna2PictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox2.TabIndex = 2;
            guna2PictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(74, 66);
            label2.Name = "label2";
            label2.Size = new Size(80, 21);
            label2.TabIndex = 1;
            label2.Text = "Availables";
            // 
            // guna2Panel7
            // 
            guna2Panel7.AutoRoundedCorners = true;
            guna2Panel7.BackColor = Color.Transparent;
            guna2Panel7.BorderRadius = 48;
            guna2Panel7.Controls.Add(lblOnRent);
            guna2Panel7.Controls.Add(guna2PictureBox3);
            guna2Panel7.Controls.Add(label3);
            guna2Panel7.CustomizableEdges = customizableEdges11;
            guna2Panel7.FillColor = Color.Gray;
            guna2Panel7.Location = new Point(667, 119);
            guna2Panel7.Name = "guna2Panel7";
            guna2Panel7.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2Panel7.Size = new Size(200, 99);
            guna2Panel7.TabIndex = 2;
            guna2Panel7.Paint += guna2Panel7_Paint;
            // 
            // lblOnRent
            // 
            lblOnRent.AutoSize = true;
            lblOnRent.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblOnRent.Location = new Point(97, 19);
            lblOnRent.Name = "lblOnRent";
            lblOnRent.Size = new Size(0, 40);
            lblOnRent.TabIndex = 5;
            // 
            // guna2PictureBox3
            // 
            guna2PictureBox3.CustomizableEdges = customizableEdges9;
            guna2PictureBox3.Image = (Image)resources.GetObject("guna2PictureBox3.Image");
            guna2PictureBox3.ImageRotate = 0F;
            guna2PictureBox3.Location = new Point(15, 34);
            guna2PictureBox3.Name = "guna2PictureBox3";
            guna2PictureBox3.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2PictureBox3.Size = new Size(44, 39);
            guna2PictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox3.TabIndex = 2;
            guna2PictureBox3.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(80, 65);
            label3.Name = "label3";
            label3.Size = new Size(67, 21);
            label3.TabIndex = 1;
            label3.Text = "On Rent";
            // 
            // guna2Panel8
            // 
            guna2Panel8.AutoRoundedCorners = true;
            guna2Panel8.BackColor = Color.Transparent;
            guna2Panel8.BorderRadius = 48;
            guna2Panel8.Controls.Add(guna2PictureBox4);
            guna2Panel8.Controls.Add(label4);
            guna2Panel8.CustomizableEdges = customizableEdges7;
            guna2Panel8.FillColor = Color.Olive;
            guna2Panel8.Location = new Point(925, 119);
            guna2Panel8.Name = "guna2Panel8";
            guna2Panel8.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2Panel8.Size = new Size(200, 99);
            guna2Panel8.TabIndex = 3;
            // 
            // guna2PictureBox4
            // 
            guna2PictureBox4.CustomizableEdges = customizableEdges5;
            guna2PictureBox4.Image = (Image)resources.GetObject("guna2PictureBox4.Image");
            guna2PictureBox4.ImageRotate = 0F;
            guna2PictureBox4.Location = new Point(15, 34);
            guna2PictureBox4.Name = "guna2PictureBox4";
            guna2PictureBox4.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2PictureBox4.Size = new Size(44, 39);
            guna2PictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox4.TabIndex = 2;
            guna2PictureBox4.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(65, 66);
            label4.Name = "label4";
            label4.Size = new Size(85, 21);
            label4.TabIndex = 1;
            label4.Text = "On Service";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(111, 10);
            label5.Name = "label5";
            label5.Size = new Size(104, 25);
            label5.TabIndex = 0;
            label5.Text = "Dashboard";
            // 
            // gunaAreaDataset1
            // 
            gunaAreaDataset1.BorderColor = Color.Empty;
            gunaAreaDataset1.FillColor = Color.Empty;
            gunaAreaDataset1.Label = "Area1";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(107, 299);
            label6.Name = "label6";
            label6.Size = new Size(183, 21);
            label6.TabIndex = 4;
            label6.Text = "Available Vehicle by Type";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top;
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(764, 299);
            label7.Name = "label7";
            label7.Size = new Size(141, 21);
            label7.TabIndex = 5;
            label7.Text = "Revenue by Month";
            // 
            // gunaChart1
            // 
            gunaChart1.BackColor = Color.FromArgb(23, 89, 119);
            chartFont9.FontName = "Arial";
            gunaChart1.Legend.LabelFont = chartFont9;
            gunaChart1.Location = new Point(94, 331);
            gunaChart1.Name = "gunaChart1";
            gunaChart1.Size = new Size(419, 260);
            gunaChart1.TabIndex = 6;
            chartFont10.FontName = "Arial";
            chartFont10.Size = 12;
            chartFont10.Style = Guna.Charts.WinForms.ChartFontStyle.Bold;
            gunaChart1.Title.Font = chartFont10;
            chartFont11.FontName = "Arial";
            gunaChart1.Tooltips.BodyFont = chartFont11;
            chartFont12.FontName = "Arial";
            chartFont12.Size = 9;
            chartFont12.Style = Guna.Charts.WinForms.ChartFontStyle.Bold;
            gunaChart1.Tooltips.TitleFont = chartFont12;
            gunaChart1.XAxes.Display = false;
            gunaChart1.XAxes.GridLines = grid4;
            chartFont13.FontName = "Arial";
            tick4.Font = chartFont13;
            gunaChart1.XAxes.Ticks = tick4;
            gunaChart1.YAxes.Display = false;
            gunaChart1.YAxes.GridLines = grid5;
            chartFont14.FontName = "Arial";
            tick5.Font = chartFont14;
            gunaChart1.YAxes.Ticks = tick5;
            gunaChart1.ZAxes.GridLines = grid6;
            chartFont15.FontName = "Arial";
            pointLabel2.Font = chartFont15;
            gunaChart1.ZAxes.PointLabels = pointLabel2;
            chartFont16.FontName = "Arial";
            tick6.Font = chartFont16;
            gunaChart1.ZAxes.Ticks = tick6;
            // 
            // gunaChart2
            // 
            gunaChart2.BackColor = Color.FromArgb(23, 89, 119);
            chartFont1.FontName = "Arial";
            gunaChart2.Legend.LabelFont = chartFont1;
            gunaChart2.Location = new Point(747, 331);
            gunaChart2.Name = "gunaChart2";
            gunaChart2.Size = new Size(499, 289);
            gunaChart2.TabIndex = 7;
            chartFont2.FontName = "Arial";
            chartFont2.Size = 12;
            chartFont2.Style = Guna.Charts.WinForms.ChartFontStyle.Bold;
            gunaChart2.Title.Font = chartFont2;
            chartFont3.FontName = "Arial";
            gunaChart2.Tooltips.BodyFont = chartFont3;
            chartFont4.FontName = "Arial";
            chartFont4.Size = 9;
            chartFont4.Style = Guna.Charts.WinForms.ChartFontStyle.Bold;
            gunaChart2.Tooltips.TitleFont = chartFont4;
            grid1.Display = false;
            gunaChart2.XAxes.GridLines = grid1;
            tick1.Display = false;
            chartFont5.FontName = "Arial";
            tick1.Font = chartFont5;
            gunaChart2.XAxes.Ticks = tick1;
            gunaChart2.YAxes.GridLines = grid2;
            chartFont6.FontName = "Arial";
            tick2.Font = chartFont6;
            gunaChart2.YAxes.Ticks = tick2;
            gunaChart2.ZAxes.GridLines = grid3;
            chartFont7.FontName = "Arial";
            pointLabel1.Font = chartFont7;
            gunaChart2.ZAxes.PointLabels = pointLabel1;
            chartFont8.FontName = "Arial";
            tick3.Font = chartFont8;
            gunaChart2.ZAxes.Ticks = tick3;
            gunaChart2.Load += gunaChart2_Load;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1390, 757);
            Name = "Dashboard";
            Text = "Dashboard";
            guna2Panel3.ResumeLayout(false);
            guna2Panel3.PerformLayout();
            guna2CustomGradientPanel1.ResumeLayout(false);
            guna2CustomGradientPanel1.PerformLayout();
            guna2Panel2.ResumeLayout(false);
            guna2Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).EndInit();
            guna2Panel6.ResumeLayout(false);
            guna2Panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox2).EndInit();
            guna2Panel7.ResumeLayout(false);
            guna2Panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox3).EndInit();
            guna2Panel8.ResumeLayout(false);
            guna2Panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox4).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Label label4;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Label label3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Label label2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Label label1;
        private Label label5;
        private Label label6;
        private Guna.Charts.WinForms.GunaAreaDataset gunaAreaDataset1;
        private Label label7;
        private Guna.Charts.WinForms.GunaChart gunaChart1;
        private Guna.Charts.WinForms.GunaChart gunaChart2;
        public Label lblAvailable;
        public Label lblBooking;
        public Label lblOnRent;
    }
}