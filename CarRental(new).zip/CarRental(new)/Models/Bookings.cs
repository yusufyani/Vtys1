﻿using CarRental.Addes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Models
{
    public partial class Bookings : SampleModel
    {
        public Bookings()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            string qry = "SELECT r.ReservationID, r.ReservationDate, r.RentalStartDate, r.RentalEndDate, r.CustomerID, r.VehicleID, v.BrandModel, r.NetAmount FROM Reservations r INNER JOIN Vehicles v ON v.VehicleID = r.VehicleID WHERE r.ReservationDate LIKE '%" + txtSearch.Text + "%'";
            ListBox lb = new ListBox();
            lb.Items.Add(dgvid);
            lb.Items.Add(dgvReservation);
            lb.Items.Add(dgvDoS);
            lb.Items.Add(dgvDoE);
            lb.Items.Add(dgvCustomer);
            lb.Items.Add(dgvVid);
            lb.Items.Add(BrandModel);
            lb.Items.Add(DgvNet);
            MainClass.LoadData(qry, guna2DataGridView1, lb);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            new AddBooking().Show();
        }

        private void Bookings_Load(object sender, EventArgs e)
        {
            LoadData();
            // History.MoveReservationsToHistory();
        }

        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
