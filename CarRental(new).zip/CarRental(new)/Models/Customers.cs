﻿using CarRental.Addes;
using CarRental.Details;
using Guna.UI2.WinForms;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.Models
{
    public partial class Customers : SampleModel
    {
        public Customers()
        {
            InitializeComponent();
        }

        private void Customers_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        int srValue = 0;
        private void LoadData()
        {
            string qry = "SELECT * FROM Customers WHERE cFirstname LIKE '%" + txtSearch.Text + "%'";
            ListBox lb = new ListBox();
            lb.Items.Add(dgvid);
            lb.Items.Add(dgvFname);
            lb.Items.Add(dgvSname);
            lb.Items.Add(dgvEmail);
            lb.Items.Add(dgvPhone);
            lb.Items.Add(dgvusername);
            lb.Items.Add(dgvPass);
            lb.Items.Add(dgvAddress);
            lb.Items.Add(dgvimg);
            MainClass.LoadData(qry, guna2DataGridView1, lb);

        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            new btnBrowse().Show();
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void guna2DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == guna2DataGridView1.Columns["dgvDetails"].Index)
            {
                string customerName = guna2DataGridView1.Rows[e.RowIndex].Cells["dgvFname"].Value.ToString();
                byte[] customerImageBytes = guna2DataGridView1.Rows[e.RowIndex].Cells["dgvimg"].Value as byte[];
                string customerPhone = guna2DataGridView1.Rows[e.RowIndex].Cells["dgvPhone"].Value.ToString();
                string customerEmail = guna2DataGridView1.Rows[e.RowIndex].Cells["dgvEmail"].Value.ToString();
                string customerAddress = guna2DataGridView1.Rows[e.RowIndex].Cells["dgvAddress"].Value.ToString();


                if (customerImageBytes != null)
                {
                    Image customerImage = ByteArrayToImage(customerImageBytes);
                    UserDetail userDetailForm = new UserDetail(customerName, customerImage, customerPhone, customerEmail, customerAddress);

                    MainForm mainForm = Application.OpenForms.OfType<MainForm>().FirstOrDefault();
                    if (mainForm != null)
                    {
                        mainForm.AddControlls(userDetailForm);
                    }
                }
                else
                {
                    MessageBox.Show("Resim verisi boş veya geçersiz.");
                }
            }
            if (guna2DataGridView1.CurrentCell.OwningColumn.Name == "dgvDelete")
            {
                guna2MessageDialog2.Icon = Guna.UI2.WinForms.MessageDialogIcon.Question;
                guna2MessageDialog2.Buttons = Guna.UI2.WinForms.MessageDialogButtons.YesNo;

                if (guna2MessageDialog2.Show() == DialogResult.Yes)
                {
                    int id = Convert.ToInt32(guna2DataGridView1.CurrentRow.Cells["dgvid"].Value);
                    string qry = "Delete from Customers where CustomerID= " + id + "";
                    Hashtable ht = new Hashtable();
                    MainClass.SQl(qry, ht);

                    guna2MessageDialog2.Icon = Guna.UI2.WinForms.MessageDialogIcon.Information;
                    guna2MessageDialog2.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
                    guna2MessageDialog2.Show("Silme İşlemi Başarılı!");

                    LoadData();
                }
            }
            if (guna2DataGridView1.CurrentCell.OwningColumn.Name == "dgvUpdate")
            {
                // Yeni bir btnBrowse formunu görüntüle
                btnBrowse frm = new btnBrowse();
                frm.Show();

                // frm adında bir form nesnesi oluşturun ve ilgili verileri atayın
                frm.id = Convert.ToInt32(guna2DataGridView1.CurrentRow.Cells["dgvid"].Value);
                frm.txtFname.Text = guna2DataGridView1.CurrentRow.Cells["dgvFname"].Value.ToString();
                frm.txtSname.Text = guna2DataGridView1.CurrentRow.Cells["dgvSname"].Value.ToString();
                frm.txtEmail.Text = guna2DataGridView1.CurrentRow.Cells["dgvEmail"].Value.ToString();
                frm.txtPhone.Text = guna2DataGridView1.CurrentRow.Cells["dgvPhone"].Value.ToString();
                frm.txtUname.Text = guna2DataGridView1.CurrentRow.Cells["dgvUsername"].Value.ToString();
                frm.txtPass.Text = guna2DataGridView1.CurrentRow.Cells["dgvPass"].Value.ToString();
                frm.txtAddress.Text = guna2DataGridView1.CurrentRow.Cells["dgvAddress"].Value.ToString();
                byte[] imageByteArray = (byte[])guna2DataGridView1.CurrentRow.Cells["dgvimg"].Value;

                if (imageByteArray != null && imageByteArray.Length > 0)
                {
                    // Byte dizisini bir MemoryStream ile Image nesnesine dönüştürün
                    using (MemoryStream ms = new MemoryStream(imageByteArray))
                    {
                        frm.guna2CirclePictureBox1.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    // Eğer veritabanında resim yoksa, varsayılan bir resim veya boş bir resim ayarlayabilirsiniz.
                    frm.guna2CirclePictureBox1.Image = null; // Veya başka bir varsayılan resim
                }

                // frm'yi görüntüleyin
                // frm.ShowDialog();
                LoadData();
            }


        }



        private Image ByteArrayToImage(byte[] byteArrayIn)
        {
            using (MemoryStream ms = new MemoryStream(byteArrayIn))
            {
                Image image = Image.FromStream(ms);
                return image;
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData();
        }

        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        {
            LoadData();
        }
    }
}
