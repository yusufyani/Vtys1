﻿namespace CarRental.Details.UserForms
{
    partial class UserView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserView));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            lblAddress = new Label();
            lblPhone = new Label();
            lblEmail = new Label();
            lblSurname = new Label();
            lblFirstname = new Label();
            guna2CircleButton7 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton6 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton5 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton4 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton3 = new Guna.UI2.WinForms.Guna2CircleButton();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            guna2vSeparator2 = new Guna.UI2.WinForms.Guna2VSeparator();
            guna2vSeparator1 = new Guna.UI2.WinForms.Guna2VSeparator();
            guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            lblUsername = new Label();
            guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            label9 = new Label();
            guna2CustomGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            guna2Panel2.SuspendLayout();
            guna2Panel7.SuspendLayout();
            guna2Panel6.SuspendLayout();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges1;
            // 
            // guna2Panel3
            // 
            guna2Panel3.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Panel3.Size = new Size(1980, 44);
            // 
            // guna2Panel4
            // 
            guna2Panel4.ShadowDecoration.CustomizableEdges = customizableEdges3;
            // 
            // guna2Panel5
            // 
            guna2Panel5.ShadowDecoration.CustomizableEdges = customizableEdges4;
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.Controls.Add(guna2Panel6);
            guna2CustomGradientPanel1.Controls.Add(guna2Panel7);
            guna2CustomGradientPanel1.Controls.Add(guna2Panel2);
            guna2CustomGradientPanel1.Controls.Add(guna2CirclePictureBox1);
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges19;
            guna2CustomGradientPanel1.Size = new Size(1257, 677);
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.BackColor = Color.Transparent;
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(95, 57);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(138, 136);
            guna2CirclePictureBox1.TabIndex = 0;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // guna2Panel2
            // 
            guna2Panel2.Controls.Add(lblAddress);
            guna2Panel2.Controls.Add(lblPhone);
            guna2Panel2.Controls.Add(lblEmail);
            guna2Panel2.Controls.Add(lblSurname);
            guna2Panel2.Controls.Add(lblFirstname);
            guna2Panel2.Controls.Add(guna2CircleButton7);
            guna2Panel2.Controls.Add(guna2CircleButton6);
            guna2Panel2.Controls.Add(guna2CircleButton5);
            guna2Panel2.Controls.Add(guna2CircleButton4);
            guna2Panel2.Controls.Add(guna2CircleButton3);
            guna2Panel2.Controls.Add(label8);
            guna2Panel2.Controls.Add(label7);
            guna2Panel2.Controls.Add(label6);
            guna2Panel2.Controls.Add(label5);
            guna2Panel2.Controls.Add(label4);
            guna2Panel2.Controls.Add(guna2vSeparator2);
            guna2Panel2.Controls.Add(guna2vSeparator1);
            guna2Panel2.CustomizableEdges = customizableEdges16;
            guna2Panel2.Location = new Point(80, 280);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges17;
            guna2Panel2.Size = new Size(1063, 179);
            guna2Panel2.TabIndex = 1;
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblAddress.ForeColor = Color.SpringGreen;
            lblAddress.Location = new Point(590, 72);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(0, 21);
            lblAddress.TabIndex = 16;
            // 
            // lblPhone
            // 
            lblPhone.AutoSize = true;
            lblPhone.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblPhone.ForeColor = Color.SpringGreen;
            lblPhone.Location = new Point(244, 138);
            lblPhone.Name = "lblPhone";
            lblPhone.Size = new Size(0, 21);
            lblPhone.TabIndex = 15;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblEmail.ForeColor = Color.SpringGreen;
            lblEmail.Location = new Point(244, 72);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(0, 21);
            lblEmail.TabIndex = 14;
            // 
            // lblSurname
            // 
            lblSurname.AutoSize = true;
            lblSurname.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblSurname.ForeColor = Color.SpringGreen;
            lblSurname.Location = new Point(15, 138);
            lblSurname.Name = "lblSurname";
            lblSurname.Size = new Size(0, 21);
            lblSurname.TabIndex = 13;
            // 
            // lblFirstname
            // 
            lblFirstname.AutoSize = true;
            lblFirstname.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblFirstname.ForeColor = Color.SpringGreen;
            lblFirstname.Location = new Point(15, 68);
            lblFirstname.Name = "lblFirstname";
            lblFirstname.Size = new Size(0, 21);
            lblFirstname.TabIndex = 12;
            // 
            // guna2CircleButton7
            // 
            guna2CircleButton7.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton7.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton7.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton7.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton7.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton7.ForeColor = Color.White;
            guna2CircleButton7.Image = (Image)resources.GetObject("guna2CircleButton7.Image");
            guna2CircleButton7.Location = new Point(662, 25);
            guna2CircleButton7.Name = "guna2CircleButton7";
            guna2CircleButton7.ShadowDecoration.CustomizableEdges = customizableEdges11;
            guna2CircleButton7.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton7.Size = new Size(36, 34);
            guna2CircleButton7.TabIndex = 11;
            // 
            // guna2CircleButton6
            // 
            guna2CircleButton6.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton6.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton6.ForeColor = Color.White;
            guna2CircleButton6.Image = (Image)resources.GetObject("guna2CircleButton6.Image");
            guna2CircleButton6.Location = new Point(91, 101);
            guna2CircleButton6.Name = "guna2CircleButton6";
            guna2CircleButton6.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2CircleButton6.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton6.Size = new Size(36, 34);
            guna2CircleButton6.TabIndex = 10;
            // 
            // guna2CircleButton5
            // 
            guna2CircleButton5.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton5.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton5.ForeColor = Color.White;
            guna2CircleButton5.Image = (Image)resources.GetObject("guna2CircleButton5.Image");
            guna2CircleButton5.Location = new Point(107, 24);
            guna2CircleButton5.Name = "guna2CircleButton5";
            guna2CircleButton5.ShadowDecoration.CustomizableEdges = customizableEdges13;
            guna2CircleButton5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton5.Size = new Size(36, 34);
            guna2CircleButton5.TabIndex = 9;
            // 
            // guna2CircleButton4
            // 
            guna2CircleButton4.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton4.ForeColor = Color.White;
            guna2CircleButton4.Image = (Image)resources.GetObject("guna2CircleButton4.Image");
            guna2CircleButton4.Location = new Point(366, 101);
            guna2CircleButton4.Name = "guna2CircleButton4";
            guna2CircleButton4.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2CircleButton4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton4.Size = new Size(36, 34);
            guna2CircleButton4.TabIndex = 8;
            // 
            // guna2CircleButton3
            // 
            guna2CircleButton3.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton3.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton3.ForeColor = Color.White;
            guna2CircleButton3.Image = (Image)resources.GetObject("guna2CircleButton3.Image");
            guna2CircleButton3.Location = new Point(298, 23);
            guna2CircleButton3.Name = "guna2CircleButton3";
            guna2CircleButton3.ShadowDecoration.CustomizableEdges = customizableEdges15;
            guna2CircleButton3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton3.Size = new Size(36, 34);
            guna2CircleButton3.TabIndex = 7;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(590, 29);
            label8.Name = "label8";
            label8.Size = new Size(66, 21);
            label8.TabIndex = 6;
            label8.Text = "Address";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(244, 106);
            label7.Name = "label7";
            label7.Size = new Size(116, 21);
            label7.TabIndex = 5;
            label7.Text = "Phone Number";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(244, 29);
            label6.Name = "label6";
            label6.Size = new Size(48, 21);
            label6.TabIndex = 4;
            label6.Text = "Email";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(15, 106);
            label5.Name = "label5";
            label5.Size = new Size(73, 21);
            label5.TabIndex = 3;
            label5.Text = "Surname";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(15, 29);
            label4.Name = "label4";
            label4.Size = new Size(86, 21);
            label4.TabIndex = 2;
            label4.Text = "First Name";
            // 
            // guna2vSeparator2
            // 
            guna2vSeparator2.Location = new Point(556, 23);
            guna2vSeparator2.Name = "guna2vSeparator2";
            guna2vSeparator2.Size = new Size(8, 147);
            guna2vSeparator2.TabIndex = 1;
            // 
            // guna2vSeparator1
            // 
            guna2vSeparator1.Location = new Point(211, 23);
            guna2vSeparator1.Name = "guna2vSeparator1";
            guna2vSeparator1.Size = new Size(8, 147);
            guna2vSeparator1.TabIndex = 0;
            // 
            // guna2Panel7
            // 
            guna2Panel7.Controls.Add(lblUsername);
            guna2Panel7.Controls.Add(guna2CircleButton2);
            guna2Panel7.Controls.Add(guna2CircleButton1);
            guna2Panel7.Controls.Add(label3);
            guna2Panel7.Controls.Add(label2);
            guna2Panel7.Controls.Add(label1);
            guna2Panel7.CustomizableEdges = customizableEdges9;
            guna2Panel7.Location = new Point(276, 19);
            guna2Panel7.Name = "guna2Panel7";
            guna2Panel7.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2Panel7.Size = new Size(263, 240);
            guna2Panel7.TabIndex = 3;
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblUsername.ForeColor = Color.SpringGreen;
            lblUsername.Location = new Point(25, 88);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(0, 21);
            lblUsername.TabIndex = 5;
            // 
            // guna2CircleButton2
            // 
            guna2CircleButton2.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton2.ForeColor = Color.White;
            guna2CircleButton2.Image = (Image)resources.GetObject("guna2CircleButton2.Image");
            guna2CircleButton2.Location = new Point(97, 118);
            guna2CircleButton2.Name = "guna2CircleButton2";
            guna2CircleButton2.ShadowDecoration.CustomizableEdges = customizableEdges7;
            guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton2.Size = new Size(36, 34);
            guna2CircleButton2.TabIndex = 4;
            // 
            // guna2CircleButton1
            // 
            guna2CircleButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2CircleButton1.ForeColor = Color.White;
            guna2CircleButton1.Image = (Image)resources.GetObject("guna2CircleButton1.Image");
            guna2CircleButton1.Location = new Point(97, 47);
            guna2CircleButton1.Name = "guna2CircleButton1";
            guna2CircleButton1.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton1.Size = new Size(36, 34);
            guna2CircleButton1.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(25, 162);
            label3.Name = "label3";
            label3.Size = new Size(73, 21);
            label3.TabIndex = 2;
            label3.Text = "*********";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(15, 124);
            label2.Name = "label2";
            label2.Size = new Size(76, 21);
            label2.TabIndex = 1;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(10, 51);
            label1.Name = "label1";
            label1.Size = new Size(81, 21);
            label1.TabIndex = 0;
            label1.Text = "Username";
            // 
            // guna2Panel6
            // 
            guna2Panel6.Controls.Add(label9);
            guna2Panel6.CustomizableEdges = customizableEdges5;
            guna2Panel6.Location = new Point(95, 492);
            guna2Panel6.Name = "guna2Panel6";
            guna2Panel6.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Panel6.Size = new Size(1063, 150);
            guna2Panel6.TabIndex = 4;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(16, 12);
            label9.Name = "label9";
            label9.Size = new Size(92, 21);
            label9.TabIndex = 3;
            label9.Text = "Description:";
            // 
            // UserView
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1390, 757);
            Name = "UserView";
            Text = "UserView";
            Load += UserView_Load;
            guna2CustomGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            guna2Panel2.ResumeLayout(false);
            guna2Panel2.PerformLayout();
            guna2Panel7.ResumeLayout(false);
            guna2Panel7.PerformLayout();
            guna2Panel6.ResumeLayout(false);
            guna2Panel6.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2VSeparator guna2vSeparator2;
        private Guna.UI2.WinForms.Guna2VSeparator guna2vSeparator1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Label lblUsername;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton7;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton6;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton5;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton4;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton3;
        private Label lblAddress;
        private Label lblPhone;
        private Label lblEmail;
        private Label lblSurname;
        private Label lblFirstname;
        private Label label9;
    }
}