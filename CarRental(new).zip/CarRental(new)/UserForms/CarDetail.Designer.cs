﻿namespace CarRental.UserForms
{
    partial class CarDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CarDetail));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            lblDescription = new Label();
            lblCategory = new Label();
            lblDailyRate = new Label();
            lblFuelType = new Label();
            label10 = new Label();
            lblYear = new Label();
            lblBrandModel = new Label();
            label8 = new Label();
            label7 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            guna2vSeparator2 = new Guna.UI2.WinForms.Guna2VSeparator();
            guna2vSeparator1 = new Guna.UI2.WinForms.Guna2VSeparator();
            ImageBox = new Guna.UI2.WinForms.Guna2PictureBox();
            btnBack = new Guna.UI2.WinForms.Guna2Button();
            btnNext = new Guna.UI2.WinForms.Guna2Button();
            lblAvailability = new Label();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2CustomGradientPanel1.SuspendLayout();
            guna2Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ImageBox).BeginInit();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges1;
            // 
            // guna2Panel3
            // 
            guna2Panel3.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Panel3.Size = new Size(1980, 44);
            // 
            // guna2Panel4
            // 
            guna2Panel4.ShadowDecoration.CustomizableEdges = customizableEdges3;
            // 
            // guna2Panel5
            // 
            guna2Panel5.ShadowDecoration.CustomizableEdges = customizableEdges4;
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.Controls.Add(guna2Button1);
            guna2CustomGradientPanel1.Controls.Add(lblAvailability);
            guna2CustomGradientPanel1.Controls.Add(btnNext);
            guna2CustomGradientPanel1.Controls.Add(btnBack);
            guna2CustomGradientPanel1.Controls.Add(ImageBox);
            guna2CustomGradientPanel1.Controls.Add(guna2Panel2);
            guna2CustomGradientPanel1.Controls.Add(guna2Button6);
            guna2CustomGradientPanel1.ForeColor = Color.SpringGreen;
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges17;
            guna2CustomGradientPanel1.Size = new Size(1252, 677);
            // 
            // guna2Button6
            // 
            guna2Button6.AutoRoundedCorners = true;
            guna2Button6.BackColor = Color.FromArgb(23, 89, 119);
            guna2Button6.BorderRadius = 34;
            guna2Button6.CustomizableEdges = customizableEdges15;
            guna2Button6.DisabledState.BorderColor = Color.DarkGray;
            guna2Button6.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button6.FillColor = Color.Transparent;
            guna2Button6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button6.ForeColor = Color.White;
            guna2Button6.Image = (Image)resources.GetObject("guna2Button6.Image");
            guna2Button6.ImageSize = new Size(70, 70);
            guna2Button6.Location = new Point(30, 32);
            guna2Button6.Name = "guna2Button6";
            guna2Button6.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2Button6.Size = new Size(80, 71);
            guna2Button6.TabIndex = 8;
            // 
            // guna2Panel2
            // 
            guna2Panel2.Controls.Add(lblDescription);
            guna2Panel2.Controls.Add(lblCategory);
            guna2Panel2.Controls.Add(lblDailyRate);
            guna2Panel2.Controls.Add(lblFuelType);
            guna2Panel2.Controls.Add(label10);
            guna2Panel2.Controls.Add(lblYear);
            guna2Panel2.Controls.Add(lblBrandModel);
            guna2Panel2.Controls.Add(label8);
            guna2Panel2.Controls.Add(label7);
            guna2Panel2.Controls.Add(label5);
            guna2Panel2.Controls.Add(label4);
            guna2Panel2.Controls.Add(label3);
            guna2Panel2.Controls.Add(label2);
            guna2Panel2.Controls.Add(label1);
            guna2Panel2.Controls.Add(guna2vSeparator2);
            guna2Panel2.Controls.Add(guna2vSeparator1);
            guna2Panel2.CustomizableEdges = customizableEdges13;
            guna2Panel2.ForeColor = Color.SpringGreen;
            guna2Panel2.Location = new Point(49, 303);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2Panel2.Size = new Size(1156, 216);
            guna2Panel2.TabIndex = 9;
            // 
            // lblDescription
            // 
            lblDescription.AutoSize = true;
            lblDescription.BackColor = Color.Transparent;
            lblDescription.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblDescription.ForeColor = Color.SpringGreen;
            lblDescription.Location = new Point(835, 75);
            lblDescription.Name = "lblDescription";
            lblDescription.Size = new Size(0, 25);
            lblDescription.TabIndex = 21;
            // 
            // lblCategory
            // 
            lblCategory.AutoSize = true;
            lblCategory.BackColor = Color.Transparent;
            lblCategory.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblCategory.ForeColor = Color.SpringGreen;
            lblCategory.Location = new Point(566, 166);
            lblCategory.Name = "lblCategory";
            lblCategory.Size = new Size(0, 25);
            lblCategory.TabIndex = 20;
            // 
            // lblDailyRate
            // 
            lblDailyRate.AutoSize = true;
            lblDailyRate.BackColor = Color.Transparent;
            lblDailyRate.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblDailyRate.ForeColor = Color.SpringGreen;
            lblDailyRate.Location = new Point(566, 75);
            lblDailyRate.Name = "lblDailyRate";
            lblDailyRate.Size = new Size(0, 25);
            lblDailyRate.TabIndex = 19;
            // 
            // lblFuelType
            // 
            lblFuelType.AutoSize = true;
            lblFuelType.BackColor = Color.Transparent;
            lblFuelType.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblFuelType.ForeColor = Color.SpringGreen;
            lblFuelType.Location = new Point(315, 166);
            lblFuelType.Name = "lblFuelType";
            lblFuelType.Size = new Size(0, 25);
            lblFuelType.TabIndex = 18;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.SpringGreen;
            label10.Location = new Point(315, 75);
            label10.Name = "label10";
            label10.Size = new Size(0, 25);
            label10.TabIndex = 17;
            // 
            // lblYear
            // 
            lblYear.AutoSize = true;
            lblYear.BackColor = Color.Transparent;
            lblYear.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblYear.ForeColor = Color.SpringGreen;
            lblYear.Location = new Point(40, 166);
            lblYear.Name = "lblYear";
            lblYear.Size = new Size(0, 25);
            lblYear.TabIndex = 16;
            // 
            // lblBrandModel
            // 
            lblBrandModel.AutoSize = true;
            lblBrandModel.BackColor = Color.Transparent;
            lblBrandModel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblBrandModel.ForeColor = Color.SpringGreen;
            lblBrandModel.Location = new Point(40, 75);
            lblBrandModel.Name = "lblBrandModel";
            lblBrandModel.Size = new Size(0, 25);
            lblBrandModel.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(543, 122);
            label8.Name = "label8";
            label8.Size = new Size(88, 25);
            label8.TabIndex = 8;
            label8.Text = "Category";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(543, 26);
            label7.Name = "label7";
            label7.Size = new Size(96, 25);
            label7.TabIndex = 7;
            label7.Text = "Daily Rate";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(835, 26);
            label5.Name = "label5";
            label5.Size = new Size(108, 25);
            label5.TabIndex = 6;
            label5.Text = "Description";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(295, 122);
            label4.Name = "label4";
            label4.Size = new Size(91, 25);
            label4.TabIndex = 5;
            label4.Text = "Fuel Type";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(295, 26);
            label3.Name = "label3";
            label3.Size = new Size(128, 25);
            label3.TabIndex = 4;
            label3.Text = "Plate Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(28, 122);
            label2.Name = "label2";
            label2.Size = new Size(48, 25);
            label2.TabIndex = 3;
            label2.Text = "Year";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(28, 26);
            label1.Name = "label1";
            label1.Size = new Size(123, 25);
            label1.TabIndex = 2;
            label1.Text = "Brand/Model";
            // 
            // guna2vSeparator2
            // 
            guna2vSeparator2.Location = new Point(779, 26);
            guna2vSeparator2.Name = "guna2vSeparator2";
            guna2vSeparator2.Size = new Size(28, 165);
            guna2vSeparator2.TabIndex = 1;
            // 
            // guna2vSeparator1
            // 
            guna2vSeparator1.Location = new Point(242, 26);
            guna2vSeparator1.Name = "guna2vSeparator1";
            guna2vSeparator1.Size = new Size(28, 165);
            guna2vSeparator1.TabIndex = 0;
            // 
            // ImageBox
            // 
            ImageBox.CustomizableEdges = customizableEdges11;
            ImageBox.ImageRotate = 0F;
            ImageBox.Location = new Point(246, 32);
            ImageBox.Name = "ImageBox";
            ImageBox.ShadowDecoration.CustomizableEdges = customizableEdges12;
            ImageBox.Size = new Size(784, 252);
            ImageBox.TabIndex = 10;
            ImageBox.TabStop = false;
            // 
            // btnBack
            // 
            btnBack.CustomizableEdges = customizableEdges9;
            btnBack.DisabledState.BorderColor = Color.DarkGray;
            btnBack.DisabledState.CustomBorderColor = Color.DarkGray;
            btnBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnBack.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack.ForeColor = Color.White;
            btnBack.Image = (Image)resources.GetObject("btnBack.Image");
            btnBack.ImageSize = new Size(70, 70);
            btnBack.Location = new Point(155, 118);
            btnBack.Name = "btnBack";
            btnBack.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnBack.Size = new Size(85, 103);
            btnBack.TabIndex = 12;
            // 
            // btnNext
            // 
            btnNext.CustomizableEdges = customizableEdges7;
            btnNext.DisabledState.BorderColor = Color.DarkGray;
            btnNext.DisabledState.CustomBorderColor = Color.DarkGray;
            btnNext.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnNext.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnNext.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnNext.ForeColor = Color.White;
            btnNext.Image = (Image)resources.GetObject("btnNext.Image");
            btnNext.ImageSize = new Size(70, 70);
            btnNext.Location = new Point(1036, 118);
            btnNext.Name = "btnNext";
            btnNext.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnNext.Size = new Size(85, 103);
            btnNext.TabIndex = 13;
            // 
            // lblAvailability
            // 
            lblAvailability.AutoSize = true;
            lblAvailability.BackColor = Color.Transparent;
            lblAvailability.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblAvailability.ForeColor = Color.SpringGreen;
            lblAvailability.Location = new Point(557, 596);
            lblAvailability.Name = "lblAvailability";
            lblAvailability.Size = new Size(0, 25);
            lblAvailability.TabIndex = 14;
            // 
            // guna2Button1
            // 
            guna2Button1.CustomizableEdges = customizableEdges5;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(1036, 596);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Button1.Size = new Size(140, 50);
            guna2Button1.TabIndex = 15;
            guna2Button1.Text = "Create Reservation";
            guna2Button1.Click += guna2Button1_Click;
            // 
            // CarDetail
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1390, 757);
            Name = "CarDetail";
            Text = "CarDetail";
            guna2CustomGradientPanel1.ResumeLayout(false);
            guna2CustomGradientPanel1.PerformLayout();
            guna2Panel2.ResumeLayout(false);
            guna2Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ImageBox).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btnBack;
        private Guna.UI2.WinForms.Guna2PictureBox ImageBox;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button btnNext;
        private Label label7;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2VSeparator guna2vSeparator2;
        private Guna.UI2.WinForms.Guna2VSeparator guna2vSeparator1;
        private Label label8;
        public Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        public Label lblAvailability;
        public Label lblDescription;
        public Label lblCategory;
        public Label lblDailyRate;
        public Label lblFuelType;
        public Label label10;
        public Label lblYear;
        public Label lblBrandModel;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}