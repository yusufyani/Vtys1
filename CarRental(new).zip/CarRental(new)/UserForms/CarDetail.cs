﻿using CarRental.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental.UserForms
{
    public partial class CarDetail : SampleModel
    {
        public CarDetail(string BrandModel, Image VehicleIMG, string Year, string PlateNumber,
                         string FuelType, bool Availability, int catID, Image eimage1, Image eimage2, Image eimage3, string Description, decimal DailyRentalRate)

        {
            InitializeComponent();

            lblBrandModel.Text = BrandModel;
            ImageBox.Image = VehicleIMG;
            lblYear.Text = Year;
            label10.Text = PlateNumber;
            lblFuelType.Text = FuelType;
            //lblCategory.Text = catID.ToString();
            //pictureBoxEImage1.Image = eImage1;
            //pictureBoxEImage2.Image = eImage2;
            //pictureBoxEImage3.Image = eImage3;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

        }
    }
}
