﻿using CarRental.Models;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using System.Drawing;
using System.IO;

namespace CarRental.UserForms
{
    public partial class Vehicles : SampleModel
    {
        private int selectedVehicleID; // Seçilen aracın kimliği

        public Vehicles()
        {
            InitializeComponent();
        }

        private void Vehicles_Load(object sender, EventArgs e)
        {
            // Veritabanı bağlantı dizesi
            string connectionString = "Data Source=DESKTOP-4QDUE5V;Initial Catalog=CarRental;User ID=sa;Password=1";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM Vehicles";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Araç verilerini veritabanından çekin (örneğin, DataTable kullanarak)
                        DataTable vehicleData = new DataTable();
                        vehicleData.Load(reader);

                        int buttonCount = 0; // Her bir satırdaki buton sayısını takip etmek için bir sayıcı
                        int buttonsPerRow = 6; // Her satırdaki buton sayısını belirleyin
                        FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel();
                        flowLayoutPanel.Dock = DockStyle.Fill;

                        // Her bir araç için bir buton oluşturun ve özelliklerini ayarlayın
                        int marginBetweenRows = 50;
                        foreach (DataRow row in vehicleData.Rows)
                        {
                            Guna2CircleButton guna2CircleButton = new Guna2CircleButton();

                            // Byte dizisini bir resme dönüştürmek
                            byte[] imageBytes = (byte[])row["vehicleIMG"];
                            using (MemoryStream ms = new MemoryStream(imageBytes))
                            {
                                // Resmi kaldırın
                                guna2CircleButton.Image = null;
                            }

                            guna2CircleButton.BackgroundImageLayout = ImageLayout.Zoom;
                            guna2CircleButton.ImageSize = new Size(170, 150);
                            guna2CircleButton.Size = new Size(150, 150); // Daire şeklinde olduğu için boyutları eşit yapabilirsiniz

                            // Aracın BrandModel bilgisini button'un metni olarak ayarlayın
                            guna2CircleButton.Text = row["BrandModel"].ToString();

                            // Diğer kodlar...

                            // Butonu panelin içine ekleyin
                            flowLayoutPanel.Controls.Add(guna2CircleButton);

                            // Butona tıklanma olayını tanımlayabilirsiniz
                            guna2CircleButton.Click += (s, ev) =>
                            {
                                // Seçilen aracın kimliğini belirleyin
                                selectedVehicleID = Convert.ToInt32(row["VehicleID"]);

                                // Diğer verileri çekmek ve CarDetail formunu göstermek için aşağıdaki işlemleri yapabilirsiniz
                                ShowCarDetailForm();
                            };

                            buttonCount++;
                            if (buttonCount % buttonsPerRow == 0)
                            {
                                // Her "buttonsPerRow" kadar buton ekledikten sonra bir sonraki satıra geçin
                                flowLayoutPanel.SetFlowBreak(guna2CircleButton, true);
                            }
                        }

                        guna2CustomGradientPanel1.Controls.Add(flowLayoutPanel);
                    }
                }
            }
        }

        private void ShowCarDetailForm()
        {
            int catID = 0;
            string brandModel = "";
            string year = "";
            string plateNumber = "";
            string fuelType = "";
            string description = "";
            decimal dailyRentalRate = 0;
            bool availability = false;
            byte[] vehicleIMG = null;
            byte[] eImage1 = null;
            byte[] eImage2 = null;
            byte[] eImage3 = null;

            string connectionString = "Data Source=DESKTOP-4QDUE5V;Initial Catalog=CarRental;User ID=sa;Password=1";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Veritabanından verileri çekmek için bir SQL sorgusu
                string query = "SELECT * FROM Vehicles WHERE VehicleID = @VehicleID"; // Burada VehicleID, ilgili aracın benzersiz kimliğini temsil eder

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Eğer bir parametre kullanmanız gerekiyorsa, parametreyi ekleyin
                    command.Parameters.AddWithValue("@VehicleID", selectedVehicleID); // selectedVehicleID, seçili aracın kimliği olsun

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read()) // Verileri oku
                        {
                            // Verileri değişkenlere atayın
                            brandModel = reader["BrandModel"].ToString();
                            year = reader["Year"].ToString();
                            plateNumber = reader["PlateNumber"].ToString();
                            fuelType = reader["FuelType"].ToString();
                            description = reader["Description"].ToString();
                            dailyRentalRate = (decimal)reader["DailyRentalRate"];
                            availability = (bool)reader["Availability"];
                            catID = (int)reader["CatID"];
                            vehicleIMG = (byte[])reader["vehicleIMG"];
                            eImage1 = (byte[])reader["eImage1"];
                            eImage2 = (byte[])reader["eImage2"];
                            eImage3 = (byte[])reader["eImage3"];
                        }
                    }
                }
            }

            // Verileri kullanarak CarDetail formunu oluşturun ve gösterin
            CarDetail carDetailForm = new CarDetail(
                brandModel,
                ByteArrayToImage(vehicleIMG),
                year,
                plateNumber,
                fuelType,
                availability,
                catID,
                ByteArrayToImage(eImage1),
                ByteArrayToImage(eImage2),
                ByteArrayToImage(eImage3),
                description,
                dailyRentalRate
            );
            carDetailForm.Show();
        }

        public static Image ByteArrayToImage(byte[] byteArray)
        {
            if (byteArray == null || byteArray.Length == 0)
                return null;

            using (MemoryStream ms = new MemoryStream(byteArray))
            {
                Image image = Image.FromStream(ms);
                return image;
            }
        }

        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        {
        }
    }
}













