﻿using CarRental.Models;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CarRental.Details.UserForms
{
    public partial class UserView : SampleModel
    {
        public UserView(int customerID)
        {
            InitializeComponent();
            LoadUserData(customerID);
        }
        private void UserView_Load(object sender, EventArgs e)
        {

        }
        private void LoadUserData(int customerID)
        {
            // Veritabanından kullanıcı bilgilerini çekmek için SQL sorgusu
            string query = "SELECT cFirstName, cLastName, cEmail, cPhone, cUsername, cPass, cAddress, customerIMG FROM Customers WHERE CustomerID = @customerID";

            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-4QDUE5V;Initial Catalog=CarRental;User ID=sa;Password=1"))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@customerID", customerID);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Verileri kontrol öğelerine doldur
                            lblFirstname.Text = reader["cFirstName"].ToString();
                            lblSurname.Text = reader["cLastName"].ToString();
                            lblEmail.Text = reader["cEmail"].ToString();
                            lblPhone.Text = reader["cPhone"].ToString();
                            lblUsername.Text = reader["cUsername"].ToString();
                            lblAddress.Text = reader["cAddress"].ToString();

                            // Kullanıcı resmini yükle
                            byte[] imageArray = (byte[])reader["customerIMG"];
                            using (System.IO.MemoryStream ms = new System.IO.MemoryStream(imageArray))
                            {
                                guna2CirclePictureBox1.Image = Image.FromStream(ms);
                                guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                            }
                        }
                    }
                }
            }
        }
    }
}

